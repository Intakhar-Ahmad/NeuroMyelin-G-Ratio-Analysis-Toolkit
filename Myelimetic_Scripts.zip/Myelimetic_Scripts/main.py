import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
import os
import re
import importlib
import sys
from functools import partial

# Global variables to store control and experimental dataframes
df_ctl = None
df_exp = None

def lazy_import(module_name):
    """
    Dynamically import a module only when needed.
    Returns None if import fails, preventing application crashes.
    
    Args:
        module_name: Name of the module to import
    
    Returns:
        Imported module or None if import fails
    """
    try:
        return importlib.import_module(module_name)
    except ImportError as e:
        print(f"Error importing {module_name}: {e}")
        return None

# Cache to store imported modules to avoid repeated imports
module_cache = {}

def get_module(module_name, is_ctl=True):
    """
    Get the appropriate module for either control or experimental data processing.
    Uses a caching mechanism to improve performance.
    
    Args:
        module_name: Base name of the module
        is_ctl: Boolean flag to determine if control (True) or experimental (False) module is needed
    
    Returns:
        The requested module or None if it cannot be imported
    """
    cache_key = f"{module_name}_{'ctl' if is_ctl else 'exp'}"
    
    if cache_key in module_cache:
        return module_cache[cache_key]
    
    # For experimental data, append '2' to the module name (e.g., 'histogram' vs 'histogram2')
    full_module_name = module_name if is_ctl else f"{module_name}2"
    module = lazy_import(full_module_name)
    
    if module:
        module_cache[cache_key] = module
        return module
    return None

def get_experiment_columns(df):
    """
    Identify paired columns representing axon and myelin measurements in the dataframe.
    
    The function looks for columns with names ending in '_Ax' (axon) and '_My' (myelin),
    then pairs them based on their base names.
    
    Args:
        df: Pandas DataFrame containing experimental data
    
    Returns:
        List of tuples where each tuple contains a matched pair of (axon_column, myelin_column)
    """
    # Find all columns ending with '_Ax' (axon measurements)
    ax_cols = [col for col in df.columns if re.search(r'_Ax$', col)]
    
    # Find all columns ending with '_My' (myelin measurements)
    my_cols = [col for col in df.columns if re.search(r'_My$', col)]
    
    # Match corresponding Ax and My columns based on their base names
    experiments = []
    for ax_col in ax_cols:
        base_name = ax_col.rsplit('_', 1)[0]  # Extract the base name (e.g., 'Exp1' from 'Exp1_Ax')
        corresponding_my_col = f"{base_name}_My"
        if corresponding_my_col in my_cols:
            experiments.append((ax_col, corresponding_my_col))
    
    return experiments

def load_file(is_ctl=True):
    """
    Open a file dialog to let the user select an Excel file to load.
    Store the loaded data in the appropriate global variable (df_ctl or df_exp).
    
    Args:
        is_ctl: Boolean flag to determine if loading control (True) or experimental (False) data
    """
    global df_ctl, df_exp
    file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx *.xls")])
    if file_path:
        try:
            # Load the Excel file into a pandas DataFrame
            df = pd.read_excel(file_path, engine='openpyxl')
            
            # Store in the appropriate global variable
            if is_ctl:
                df_ctl = df
            else:
                df_exp = df
                
            # Display success message
            label = "CTL" if is_ctl else "EXP"
            messagebox.showinfo("Success", f"{label} file is successfully loaded!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load file: {e}")

def cleanup_data_handler(is_ctl=True):
    """
    Clean up the loaded data by calling the appropriate data_cleanup module.
    
    Args:
        is_ctl: Boolean flag to determine if processing control (True) or experimental (False) data
    """
    # Get the appropriate dataframe (control or experimental)
    df = df_ctl if is_ctl else df_exp
    
    if df is not None:
        # Get the experiment column pairs
        experiments = get_experiment_columns(df)
        if experiments:
            # Load the appropriate data cleanup module
            module = get_module("data_cleanup", is_ctl)
            if module:
                # Call the data_cleanup function from the module
                status, message = module.data_cleanup(df, experiments)
                if status == "Success":
                    messagebox.showinfo(status, message)
                else:
                    messagebox.showerror(status, message)
            else:
                messagebox.showerror("Error", "Module not found")
        else:
            label = "CTL" if is_ctl else "EXP"
            messagebox.showerror("Error", f"No valid experiment column pairs found in {label} data.")
    else:
        label = "CTL" if is_ctl else "EXP"
        messagebox.showerror("Error", f"No {label} data loaded.")

def process_fiber_data_handler(is_ctl=True):
    """
    Process fiber data by calculating fiber diameters from axon and myelin measurements.
    Updates the global dataframe with the calculated values.
    
    Args:
        is_ctl: Boolean flag to determine if processing control (True) or experimental (False) data
    """
    global df_ctl, df_exp
    df = df_ctl if is_ctl else df_exp
    
    if df is not None:
        experiments = get_experiment_columns(df)
        if experiments:
            # Load the appropriate fiber diameter processing module
            module = get_module("fiber_diameter", is_ctl)
            if module:
                # Process the fiber data using the module
                result_df = module.process_fiber_data(df, experiments)
                
                # Update the global dataframe with the results
                if is_ctl:
                    df_ctl = result_df
                else:
                    df_exp = result_df
                    
                label = "CTL" if is_ctl else "EXP"
                messagebox.showinfo("Success", f"Fiber data generation for {label} is successful.")
            else:
                messagebox.showerror("Error", "Module not found")
        else:
            label = "CTL" if is_ctl else "EXP"
            messagebox.showerror("Error", f"No valid experiment column pairs found in {label} data.")
    else:
        label = "CTL" if is_ctl else "EXP"
        messagebox.showerror("Error", f"No {label} data loaded to process.")

def calculate_g_ratio_handler(is_ctl=True):
    """
    Calculate g-ratios (axon diameter / fiber diameter) for all experiments.
    Updates the global dataframe with the calculated g-ratio values.
    
    Args:
        is_ctl: Boolean flag to determine if processing control (True) or experimental (False) data
    """
    global df_ctl, df_exp
    df = df_ctl if is_ctl else df_exp
    
    if df is not None:
        experiments = get_experiment_columns(df)
        if experiments:
            # Load the appropriate g-ratio calculation module
            module = get_module("g_ratio", is_ctl)
            if module:
                # Calculate g-ratios using the module
                result_df = module.calculate_g_ratio(df, experiments)
                
                # Update the global dataframe with the results
                if is_ctl:
                    df_ctl = result_df
                else:
                    df_exp = result_df
                    
                label = "CTL" if is_ctl else "EXP"
                messagebox.showinfo("Success", f"G-Ratio calculation for {label} is successful.")
            else:
                messagebox.showerror("Error", "Module not found")
        else:
            label = "CTL" if is_ctl else "EXP"
            messagebox.showerror("Error", f"No valid experiment column pairs found in {label} data.")
    else:
        label = "CTL" if is_ctl else "EXP"
        messagebox.showerror("Error", f"No {label} data loaded to calculate G-ratio.")

def show_scatter_plots_handler(is_ctl=True):
    """
    Generate and save scatter plots showing the relationship between fiber diameters and axon diameters.
    
    Args:
        is_ctl: Boolean flag to determine if processing control (True) or experimental (False) data
    """
    df = df_ctl if is_ctl else df_exp
    
    if df is not None:
        experiments = get_experiment_columns(df)
        if experiments:
            # Create pairs of columns to plot (fiber diameter vs axon diameter)
            scatter_pairs = [(f'FiberDiameter_{ax_col.split("_")[0]}', ax_col) for ax_col, my_col in experiments]
            
            # Load the appropriate scatter plot module
            module = get_module("scatter_plot", is_ctl)
            
            if module:
                # Create a folder to save the scatter plots
                folder_name = "ScatterPlot_CTL" if is_ctl else "ScatterPlot_EXP"
                code_directory = os.path.dirname(os.path.realpath(__file__))
                scatter_folder_path = os.path.join(code_directory, folder_name)
                
                os.makedirs(scatter_folder_path, exist_ok=True)
                
                # Generate and save the scatter plots
                module.generate_scatter_plots(df, scatter_pairs, display=False, save_path=scatter_folder_path)
                
                label = "CTL" if is_ctl else "EXP"
                messagebox.showinfo("Success", f"{label} scatter plots are saved successfully to {folder_name} folder in the directory where the main script is located.")
            else:
                messagebox.showerror("Error", "Module not found")
        else:
            label = "CTL" if is_ctl else "EXP"
            messagebox.showerror("Error", f"No valid experiment column pairs found in {label} data.")
    else:
        label = "CTL" if is_ctl else "EXP"
        messagebox.showerror("Error", f"No {label} data loaded to generate scatter plots.")

def sort_fiber_diameter_handler(is_ctl=True):
    """
    Sort the data by fiber diameter for each experiment.
    Updates the global dataframe with the sorted data.
    
    Args:
        is_ctl: Boolean flag to determine if processing control (True) or experimental (False) data
    """
    global df_ctl, df_exp
    df = df_ctl if is_ctl else df_exp
    
    if df is not None:
        experiments = get_experiment_columns(df)
        if experiments:
            # Create tuples with columns to be sorted together
            # (fiber_diameter_column, axon_column, myelin_column, g_ratio_column)
            fiber_diameter_pairs = [(f'FiberDiameter_{exp[0].split("_")[0]}', exp[0], exp[1], f'G-Ratio_{exp[0].split("_")[0]}') for exp in experiments]
            
            # Load the appropriate sorting module (different module names for control and experimental)
            module = get_module("sorted_fiber_diameter" if is_ctl else "sorted_fiber", is_ctl)
            
            if module:
                # Sort the data using the module
                result_df = module.sort_fiber_diameter(df, fiber_diameter_pairs)
                
                # Update the global dataframe with the sorted data
                if is_ctl:
                    df_ctl = result_df
                else:
                    df_exp = result_df
                    
                label = "CTL" if is_ctl else "EXP"
                messagebox.showinfo("Success", f"{label} data are sorted by 'FiberDiameter' for each experiment.")
            else:
                messagebox.showerror("Error", "Module not found")
        else:
            label = "CTL" if is_ctl else "EXP"
            messagebox.showerror("Error", f"No valid experiment column pairs found in {label} data.")
    else:
        label = "CTL" if is_ctl else "EXP"
        messagebox.showerror("Error", f"No {label} data loaded to sort.")

def sort_and_display_handler(is_ctl=True):
    """
    Sort the data by fiber diameter and display it in a new window.
    
    Args:
        is_ctl: Boolean flag to determine if processing control (True) or experimental (False) data
    """
    df = df_ctl if is_ctl else df_exp
    
    if df is not None:
        experiments = get_experiment_columns(df)
        if experiments:
            # Create tuples with columns to be sorted together
            fiber_diameter_pairs = [(f'FiberDiameter_{exp[0].split("_")[0]}', exp[0], exp[1], f'G-Ratio_{exp[0].split("_")[0]}') for exp in experiments]
            
            # Load the sorting and display modules
            module_sort = get_module("sorted_fiber_diameter" if is_ctl else "sorted_fiber", is_ctl)
            module_display = get_module("display_data", is_ctl)
            
            if module_sort and module_display:
                # Sort the data first
                sorted_df = module_sort.sort_fiber_diameter(df, fiber_diameter_pairs)
                
                # Then display it in a new window
                module_display.display_dataframe(sorted_df, root)
            else:
                messagebox.showerror("Error", "Module not found")
        else:
            label = "CTL" if is_ctl else "EXP"
            messagebox.showerror("Error", f"No valid experiment column pairs found in {label} data.")
    else:
        label = "CTL" if is_ctl else "EXP"
        messagebox.showerror("Error", f"No {label} data loaded.")

def save_sorted_data(is_ctl=True):
    """
    Save the sorted data to an Excel file.
    
    Args:
        is_ctl: Boolean flag to determine if saving control (True) or experimental (False) data
    """
    df = df_ctl if is_ctl else df_exp
    
    if df is not None:
        label = "CTL" if is_ctl else "EXP"
        
        # Show a message with recommended filename
        if is_ctl:
            messagebox.showinfo("Save Information", "Save the sorted CTL data. It is recommended to save as 'Sorted-CTL' and click save.")
        else:
            messagebox.showinfo("Save Information", "Save the sorted EXP data. It is recommended to save as 'Sorted-EXP' and click save.")
        
        # Open a file save dialog
        file_path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx"), ("All Files", "*.*")],
            title=f"Save Sorted {label} Data"
        )
        
        if file_path:
            try:
                # Save the data to Excel with a custom sheet name
                custom_sheet_name = "Sorted_Fiber_Diameter" 
                with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
                    df.to_excel(writer, index=False, sheet_name=custom_sheet_name)
                messagebox.showinfo("Success", f"{label} data saved successfully to {file_path} in the sheet '{custom_sheet_name}'")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save {label} file: {e}")
    else:
        label = "CTL" if is_ctl else "EXP"
        messagebox.showerror("Error", f"No {label} data to save.")

def process_and_save_subsets_command_ctl():
    """
    Process control data to create fiber diameter subsets and save them to an Excel file.
    Also determines the diameter ranges for later use with experimental data.
    """
    global df_ctl
    if df_ctl is not None:
        # Prompt for saving the subsets file
        messagebox.showinfo("Save Subsets", "It is recommended to name it 'Subsets-CTL' and then click save.")
        subsets_file_path = filedialog.asksaveasfilename(title="Save CTL Subsets File", defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])

        # Prompt for saving the ranges file
        messagebox.showinfo("Save Ranges File", "Importent Note!! select the existing empty 'Ranges_CTL1' file and then click save. It will populate the range info in the empty file")
        ranges_file_path = filedialog.asksaveasfilename(title="Save Ranges File", defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])

        if subsets_file_path and ranges_file_path:
            # Import the subset creation module
            ctl1_subset = lazy_import("ctl1_subset")
            
            if ctl1_subset:
                experiments = get_experiment_columns(df_ctl)
                if experiments:
                    # Create an Excel writer for the subsets file
                    with pd.ExcelWriter(subsets_file_path, engine='openpyxl') as writer:
                        # Get the identifier for the first experiment
                        first_experiment = experiments[0][0].split('_')[0]
                        
                        # Create subsets for the first experiment and save the ranges
                        ctl1_ranges = ctl1_subset.create_subsets_and_save_ranges(df_ctl, f'FiberDiameter_{first_experiment}', writer, first_experiment)

                        # Create subsets for the remaining experiments using the same ranges
                        for exp in experiments[1:]:
                            base_name = exp[0].split('_')[0]
                            
                            ctl1_subset.create_subsets_based_on_ranges(
                                df_ctl[[f'FiberDiameter_{base_name}', exp[0], exp[1], f'G-Ratio_{base_name}']].dropna(),
                                f'FiberDiameter_{base_name}',
                                ctl1_ranges,
                                writer,
                                base_name
                            )

                    # Save the ranges to a separate file for later use with experimental data
                    if ctl1_ranges:
                        ctl1_subset.save_ranges(ctl1_ranges, ranges_file_path, first_experiment)

                    messagebox.showinfo("Success", "Subsets-CTL and ranges have been saved successfully.",
                                        detail=f"Subsets saved in: {subsets_file_path}\nRanges saved in: {ranges_file_path}")
                else:
                    messagebox.showerror("Error", "No valid experiment column pairs found in CTL data.")
            else:
                messagebox.showerror("Error", "Required module 'ctl1_subset' could not be loaded.")
        else:
            messagebox.showerror("Error", "No file specified for saving. Please try again.")
    else:
        messagebox.showerror("Error", "No CTL data loaded. Please load data before processing.")

def analyze_g_ratio_handler_ctl():
    """
    Analyze g-ratio statistics for control data and generate histograms.
    """
    # Load the histogram module for control data
    histogram_module = get_module("histogram", True)
    
    if not histogram_module:
        messagebox.showerror("Error", "Required module 'histogram' could not be loaded.")
        return
    
    # Prompt to select the subsets file
    messagebox.showinfo("Select File", "Please select the Subsets-CTL file for Histograms and G-Ratio statistics.")
    input_file_path = filedialog.askopenfilename(title="Open Excel file for CTL analysis", filetypes=[("Excel files", "*.xlsx"), ("Excel files", "*.xls")])
    
    if not input_file_path:
        messagebox.showerror("Error", "No input file selected. Please select a file to continue.")
        return

    # Prompt to save the statistics file
    messagebox.showinfo("Save Results", "Please save the statistical analysis for CTL, it is recomended to name it 'Stats-CTL' .")
    output_file_path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")], title="Save CTL G-Ratio analysis results as")
    
    if not output_file_path:
        messagebox.showerror("Error", "No output file selected. Please select a file to save the results.")
        return

    # Create a folder for histograms
    code_directory = os.path.dirname(os.path.realpath(__file__))
    histogram_folder_path = os.path.join(code_directory, "Histograms")
    os.makedirs(histogram_folder_path, exist_ok=True)  
    
    try:
        # Remove the output file if it already exists
        if os.path.exists(output_file_path):
            os.remove(output_file_path)  

        # Analyze g-ratio statistics
        histogram_module.analyze_g_ratio(input_file_path, output_file_path, histogram_folder_path, results_sheet_name="Statistical_analysis")
        
        # Generate g-ratio frequency histograms
        histogram_module.plot_all_g_ratio_frequencies(input_file_path, histogram_folder_path, display=False)
        
        messagebox.showinfo("Success", "CTL G-Ratio stats and histograms have been saved successfully.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

def process_and_save_subsets_command_exp():
    """
    Process experimental data to create fiber diameter subsets based on the ranges determined from control data.
    """
    global df_exp
    if df_exp is not None:
        # Import the subset creation module for experimental data
        subset_create_module = lazy_import("subset_create2")
        
        if not subset_create_module:
            messagebox.showerror("Error", "Required module 'subset_create2' could not be loaded.")
            return
        
        # Prompt to select the ranges file from control data
        messagebox.showinfo("Select Ranges File", "Choose the range file named 'Ranges_CTL1', then when prompted, save the EXP subsets. It is recommended to name it 'Subsets-EXP'.")
        ranges_file_path = filedialog.askopenfilename(title="Select Ranges File", filetypes=[("Excel files", "*.xlsx")])
        if not ranges_file_path:
            return
        
        try:
            # Load the fiber diameter ranges from the ranges file
            fiber_size_ranges = subset_create_module.load_ranges_from_file(ranges_file_path)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load: {e}")
            return
        
        # Prompt to save the experimental subsets
        output_path = filedialog.asksaveasfilename(defaultextension=".xlsx", title="Save EXP subsets")
        if output_path:
            # Create and save the experimental subsets based on the control ranges
            subset_create_module.create_and_save_subsets(df_exp, fiber_size_ranges, output_path)
            messagebox.showinfo("Success", "EXP subsets saved.")
    else:
        messagebox.showerror("Error", "No EXP data loaded.")

def analyze_g_ratio_handler_exp():
    """
    Analyze g-ratio statistics for experimental data and generate histograms.
    """
    # Load the histogram module for experimental data
    histogram_module = get_module("histogram", False)
    
    if not histogram_module:
        messagebox.showerror("Error", "Required module 'histogram2' could not be loaded.")
        return
    
    # Prompt to select the subsets file
    messagebox.showinfo("Select File", "Please select the Subsets-EXP file for Histograms and G-Ratio statistics.")
    input_file_path = filedialog.askopenfilename(title="Select input Excel file for EXP")
    if not input_file_path:
        return
    
    # Prompt to save the statistics file
    messagebox.showinfo("Save Results", "Please save the statistical analysis for EXP, it is recommended to name it 'Stats-EXP'.")
    output_file_path = filedialog.asksaveasfilename(defaultextension=".xlsx", title="Save EXP G-Ratio results")
    if not output_file_path:
        return
    
    # Create a folder for histograms
    histogram_folder_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "Histograms")
    os.makedirs(histogram_folder_path, exist_ok=True)
    
    try:
        # Remove the output file if it already exists
        if os.path.exists(output_file_path):
            os.remove(output_file_path)
        
        # Analyze g-ratio statistics
        histogram_module.analyze_g_ratio(input_file_path, output_file_path, histogram_folder_path, "Statistical_analysis")
        
        # Generate g-ratio frequency histograms
        histogram_module.plot_all_g_ratio_frequencies(input_file_path, histogram_folder_path, display=False)
        
        messagebox.showinfo("Success", "EXP G-Ratio stats and histograms have been saved successfully.")
    except Exception as e:
        messagebox.showerror("Error", str(e))
        
def grand_mean_g_ratio_handler():
    """
    Calculate the grand mean g-ratio for both control and experimental data.
    Combines data from both datasets into a single Excel file for comparison.
    """
    # Import the g-ratio mean/std module
    exp_ctl_gratio_module = lazy_import("exp_ctl_gratio_mean_std")
    
    if not exp_ctl_gratio_module:
        messagebox.showerror("Error", "Required module 'exp_ctl_gratio_mean_std' could not be loaded.")
        return
    
    # Instructions for the user
    messagebox.showinfo("Select Files", "Please select the Subset-CTL and Subset-EXP Excel files one after another, and then when prompted, save combined G-ratio data. It is recommended to name it as 'Combined G-ratios'.")
    
    # Prompt to select control and experimental files
    ctl_path = filedialog.askopenfilename(title="Select CTL Excel File", filetypes=[("Excel Files", "*.xlsx"), ("All Files", "*.*")])
    exp_path = filedialog.askopenfilename(title="Select EXP Excel File", filetypes=[("Excel Files", "*.xlsx"), ("All Files", "*.*")])
    
    if not ctl_path or not exp_path:
        messagebox.showerror("Error", "You need to select both CTL and EXP files to continue.")
        return
    
    # Prompt to save the combined data
    save_path = filedialog.asksaveasfilename(title="Save Output", defaultextension=".xlsx", filetypes=[("Excel Files", "*.xlsx"), ("All Files", "*.*")])
    
    if not save_path:
        messagebox.showerror("Error", "You need to select a file name to save the combined data.")
        return

    # Process and combine the data
    exp_ctl_gratio_module.process_data(ctl_path, exp_path, save_path)
    
    # Calculate the grand mean g-ratio for both datasets
    ctl_data = pd.read_excel(save_path, sheet_name='CTL_Data')
    exp_data = pd.read_excel(save_path, sheet_name='EXP_Data')

    ctl_grand_mean = ctl_data.filter(like='G-Ratio').mean().mean()
    exp_grand_mean = exp_data.filter(like='G-Ratio').mean().mean()
    
    messagebox.showinfo("Success", f"Data combined and saved successfully at: {save_path}")

def visualize_ctl_exp_plot():
    """
    Create a visualization comparing control and experimental g-ratios.
    """
    # Import required modules
    visual_ctl_exp_module = lazy_import("visual_ctl_exp_plot")
    plt = lazy_import("matplotlib.pyplot")
    
    if not visual_ctl_exp_module or not plt:
        messagebox.showerror("Error", "Required modules could not be loaded.")
        return
    
    # Prompt to select the combined g-ratios file
    messagebox.showinfo("Select File", "Please select the combined G-Ratios file for visualization, and when generated, adjust the image frame and close it. It will be saved in the 'Plots' folder in the Scripts directorty")
    file_path = filedialog.askopenfilename(title="Open Combined G-Ratio File", filetypes=[("Excel Files", "*.xlsx"), ("Excel Files", "*.xls")])
    
    if not file_path:
        messagebox.showerror("Error", "No file was selected.")
        return

    try:
        # Extract data from the combined file
        ctl_data, exp_data = visual_ctl_exp_module.extract_data(file_path)
    except Exception as e:
        messagebox.showerror("Error", str(e))
        return

    try:
        # Calculate and plot the means
        max_fibers_ctl = visual_ctl_exp_module.get_max_fiber_diameters(ctl_data)
        fig_ctl_exp = visual_ctl_exp_module.calculate_means_and_plot(ctl_data, exp_data, max_fibers_ctl, "CTL", "CTL", "EXP", "EXP")
        
        # Create a folder for plots if it doesn't exist
        code_directory = os.path.dirname(os.path.realpath(__file__))
        plot_directory = os.path.join(code_directory, "Plots")
        os.makedirs(plot_directory, exist_ok=True)
        
        # Save the plot to the plots folder
        fig_ctl_exp.savefig(os.path.join(plot_directory, 'CTL_EXP_plot.png'))
        messagebox.showinfo("Success", "The plot has been saved successfully in the 'Plots' folder in the Scripts directory. Values are visible on the Python shell.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")
    finally:
        plt.close('all')  # Close all matplotlib figures to free memory

def load_bg_image(path, width, height):
    """
    Load and resize a background image for the GUI.
    
    Args:
        path: Path to the image file
        width: Desired width for the resized image
        height: Desired height for the resized image
        
    Returns:
        A PhotoImage object to be used as a background in the GUI, or None if loading fails
    """
    from PIL import Image, ImageTk
    try:
        # Open and resize the image using PIL
        img = Image.open(path)
        img = img.resize((width, height), Image.Resampling.LANCZOS)
        
        # Convert to a PhotoImage that tkinter can use
        photo_img = ImageTk.PhotoImage(img)
        return photo_img
    except Exception as e:
        print(f"Error loading image: {e}")
        return None


def install_dependencies_handler():
    """
    Run the install_dependencies.py script to install required packages,
    then show a popup message indicating success.
    """
    try:
        import subprocess
        script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "install_dependencies.py")
        subprocess.check_call([sys.executable, script_path])
        messagebox.showinfo("Success", "All dependencies have been installed successfully!")
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Installation Failed", f"An error occurred while installing dependencies:\n{e}")


def create_gui():
    """
    Create the main GUI window with all buttons and background.
    
    Returns:
        The tkinter root window object
    """
    # Create the main window
    root = tk.Tk()
    root.title("MyeliMetric: Enhancing the Accuracy of G-Ratio Analysis in Myelin Research")
    
    # Set window size
    window_width, window_height = 1375, 800
    root.geometry(f"{window_width}x{window_height}")
    root.resizable(False, False)  # Prevent window resizing
    
    # Load background image
    bg_image = load_bg_image("BG-small.png", window_width, window_height)
    
    # Create a canvas for drawing
    canvas = tk.Canvas(root, width=window_width, height=window_height)
    canvas.pack(fill="both", expand=True)

    # Create "Install all dependencies" button at the top-center
    #install_button = tk.Button(root, text="Install all dependencies", command=install_dependencies_handler,
                               #width=30, height=1, bg="white", fg="black")
    #canvas.create_window(window_width // 2, 20, window=install_button)

    
    # Set the background image
    if bg_image:
        x_center = window_width // 2
        y_center = window_height // 2
        canvas.create_image(x_center, y_center, image=bg_image, anchor="center")
        canvas.image = bg_image  # Keep a reference to prevent garbage collection
    
    # Button style settings
    button_width = 35
    button_height = 1
    button_color = "white"
    text_color = "black"
    
    # Define buttons for control data processing
    ctl_button_configs = [
        ("Upload File-CTL Data (| Ax col | My col |)", partial(load_file, True)),
        ("Clean Up CTL Data", partial(cleanup_data_handler, True)),
        ("Calculate Fiber Data for CTL", partial(process_fiber_data_handler, True)),
        ("Calculate G-Ratios-CTL", partial(calculate_g_ratio_handler, True)),
        ("Scatter Plots-CTL (auto-save)", partial(show_scatter_plots_handler, True)),
        ("Sort Fiber Diameters-CTL", partial(sort_fiber_diameter_handler, True)),
        ("Display Sorted CTL Data (optional)", partial(sort_and_display_handler, True)),
        ("Save Sorted-CTL", partial(save_sorted_data, True)),
        ("Save Subsets-CTL & Determine Ranges", process_and_save_subsets_command_ctl),
        ("Generate Histograms & Save Stats-CTL", analyze_g_ratio_handler_ctl)
    ]
    
    # Define buttons for experimental data processing
    exp_button_configs = [
        ("Upload File-EXP Data (| Ax col | My col |)", partial(load_file, False)),
        ("Clean Up EXP Data", partial(cleanup_data_handler, False)),
        ("Calculate Fiber Data for EXP", partial(process_fiber_data_handler, False)),
        ("Calculate G-Ratios-EXP", partial(calculate_g_ratio_handler, False)),
        ("Scatter Plots-EXP (auto-save)", partial(show_scatter_plots_handler, False)),
        ("Sort Fiber Diameters-EXP", partial(sort_fiber_diameter_handler, False)),
        ("Display Sorted EXP Data (optional)", partial(sort_and_display_handler, False)),
        ("Save Sorted-EXP", partial(save_sorted_data, False)),
        ("Save Subsets-EXP based on CTL1 Ranges", process_and_save_subsets_command_exp),
        ("Generate Histograms & Save Stats-EXP", analyze_g_ratio_handler_exp)
    ]
    
    # Define buttons for combined analysis
    combined_button_configs = [
        ("Cal Grand Mean G-Ratio & save", grand_mean_g_ratio_handler),
        ("Show Combined Plot & Save", visualize_ctl_exp_plot)
    ]
    
    # Define positions for the buttons
    left_x = 150    # X position for control data buttons
    right_x = 1225  # X position for experimental data buttons
    center_x = 687  # X position for combined analysis buttons
    start_y = 60    # Starting Y position for buttons
    bottom_y = 600  # Y position for combined analysis buttons
    spacing = 50    # Vertical space between buttons
    
    # Create and position control data buttons on the left side
    for i, (text, command) in enumerate(ctl_button_configs):
        button = tk.Button(root, text=text, command=command, width=button_width, height=button_height, bg=button_color, fg=text_color)
        canvas.create_window(left_x, start_y + i * spacing, window=button)
    
    # Create and position experimental data buttons on the right side
    for i, (text, command) in enumerate(exp_button_configs):
        button = tk.Button(root, text=text, command=command, width=button_width, height=button_height, bg=button_color, fg=text_color)
        canvas.create_window(right_x, start_y + i * spacing, window=button)
    
    # Create and position combined analysis buttons at the bottom center
    for i, (text, command) in enumerate(combined_button_configs):
        button = tk.Button(root, text=text, command=command, width=button_width, height=button_height, bg=button_color, fg=text_color)
        canvas.create_window(center_x, bottom_y + i * spacing, window=button)
    
    return root

# Entry point for the application
if __name__ == "__main__":
    root = create_gui()  # Create the GUI
    root.mainloop()      # Start the tkinter event loop
    
"""
MyeliMetric: Enhancing the Accuracy of G-Ratio Analysis in Myelin Research

This application provides a GUI for processing and analyzing myelin sheath data in neuroscience research.
It calculates fiber diameters and g-ratios from microscopy data for both control (CTL) and experimental (EXP) samples.

The application workflow follows these main steps:
1. Load Excel data files containing axon and myelin measurements
2. Clean up and process the raw data
3. Calculate fiber diameters 
4. Calculate g-ratios (axon diameter / fiber diameter)
5. Generate visualizations (scatter plots, histograms)
6. Sort and categorize fibers by diameter
7. Create subsets based on fiber diameter ranges
8. Perform statistical analysis
9. Compare control vs experimental data

Author: Intakhar Ahmad / Farjana Sultana Chowdhury- April 2025
"""