# Define a Python script that generates the graph from the provided Excel file and saves it

# Load necessary packages
import pandas as pd
import matplotlib.pyplot as plt

# File path
file_path = "/mnt/data/Stats_CTL.xlsx"
output_path = "/mnt/data/Shapiro_Wilk_Normality_Plot.png"

# Load Excel sheet
df = pd.read_excel(file_path, sheet_name='Statistical_analysis')

# Extract required columns and rename
normality_df = df[['EXP_name', 'Shapiro-Stat', 'Shapiro-p-value', 'Normality']].copy()
normality_df.rename(columns={
    'EXP_name': 'Subset',
    'Shapiro-Stat': 'W Statistic',
    'Shapiro-p-value': 'p-value',
    'Normality': 'Non-normal'
}, inplace=True)

# Convert 'Non-normal' to boolean for consistent formatting
if normality_df['Non-normal'].dtype != bool:
    normality_df['Non-normal'] = normality_df['Non-normal'].astype(str).str.lower().isin(['true', 'yes', '1'])

# Sort by subset for consistent order
normality_df.sort_values('Subset', inplace=True)

# Plotting
fig, ax = plt.subplots(figsize=(10, 6))
bars = ax.bar(
    normality_df['Subset'],
    normality_df['p-value'],
    edgecolor='black',
    facecolor='none',
    linewidth=1.5
)
ax.axhline(0.05, color='red', linestyle='--', label='p = 0.05 threshold')
ax.set_ylabel('Shapiro-Wilk p-value')
ax.set_title('Normality Test (Shapiro-Wilk) by Fiber Diameter Subset')
ax.set_xticklabels(normality_df['Subset'], rotation=45, ha='right')
ax.legend()
ax.grid(False)  # Disable background grid

# Save the figure
plt.tight_layout()
plt.savefig(output_path, dpi=300)
output_path
