
import subprocess
import sys

# List of required packages
required_packages = [
    "tk",          # tkinter is typically included with Python installations
    "pandas",
    "numpy",
    "matplotlib",
    "scipy",
    "openpyxl",
    "pillow",
    "xlsxwriter"
    
]

# Install each package using pip
for package in required_packages:
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"Successfully installed: {package}")
    except subprocess.CalledProcessError:
        print(f"Failed to install: {package}. Please install it manually.")
