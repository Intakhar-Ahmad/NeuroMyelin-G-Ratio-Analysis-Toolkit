# scatter_plot.py - for CTL data

import matplotlib.pyplot as plt
import numpy as np
import os

def generate_scatter_plots(df, scatter_pairs, display=False, save_path=None):
    """
    Generate scatter plots for visualizing the relationship between
    fiber diameter and axon diameter, and save to the specified folder.
    
    Args:
        df: DataFrame containing the data
        scatter_pairs: List of tuples (fiber_diameter_column, axon_diameter_column)
        display: Whether to display plots (default: False)
        save_path: Path to save the plots (default: None)
    """
    if not save_path:
        # Default to current directory if no save path provided
        save_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "ScatterPlot_CTL")
        # Create the folder if it doesn't exist
        os.makedirs(save_path, exist_ok=True)
    
    for fiber_col, axon_col in scatter_pairs:
        # Extract the experiment name (e.g., 'CTL1' from 'FiberDiameter_CTL1')
        exp_name = fiber_col.split('_')[1]
        
        # Create a figure for the scatter plot
        plt.figure(figsize=(10, 8))
        
        # Filter out any rows with NaN values in either column
        valid_data = df[[fiber_col, axon_col]].dropna()
        
        # Create the scatter plot
        plt.scatter(valid_data[fiber_col], valid_data[axon_col], alpha=0.6, s=50)
        
        # Add a linear regression line
        if len(valid_data) > 1:
            # Calculate the linear regression
            slope, intercept = np.polyfit(valid_data[fiber_col], valid_data[axon_col], 1)
            # Generate points for the line
            x_line = np.linspace(valid_data[fiber_col].min(), valid_data[fiber_col].max(), 100)
            y_line = slope * x_line + intercept
            # Plot the regression line
            plt.plot(x_line, y_line, 'r-', linewidth=2)
            # Add the equation to the plot
            plt.text(0.05, 0.95, f'y = {slope:.3f}x + {intercept:.3f}', 
                     transform=plt.gca().transAxes, fontsize=12, 
                     verticalalignment='top', bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        # Add title and labels
        plt.title(f'Scatter Plot: {exp_name} Fiber Diameter vs. Axon Diameter', fontsize=14)
        plt.xlabel('Fiber Diameter (μm)', fontsize=12)
        plt.ylabel('Axon Diameter (μm)', fontsize=12)
        plt.grid(True, alpha=0.3)
        
        # Save the plot to the specified folder
        file_path = os.path.join(save_path, f'{exp_name}_scatter_plot.png')
        plt.savefig(file_path, dpi=300, bbox_inches='tight')
        
        # Display the plot if requested
        if display:
            plt.show()
        else:
            plt.close()
    
    print(f"All control scatter plots are saved to {save_path}")