import pandas as pd






def load_ranges_from_file(file_path):
    """
    Load fiber size ranges from an Excel or CSV file.
    The file should contain 'Min Fiber Diameter' and 'Max Fiber Diameter' columns.
    
    Args:
        file_path (str): Path to the ranges file.
        
    Returns:
        list of tuples: A list of (min, max) tuples representing the fiber size ranges.
    """
    if file_path.endswith('.xlsx'):
        ranges_df = pd.read_excel(file_path)
    elif file_path.endswith('.csv'):
        ranges_df = pd.read_csv(file_path)
    else:
        raise ValueError("Unsupported file format. Please select a CSV or Excel file.")

    # Ensure the file has the necessary columns
    if 'Min Fiber Diameter' not in ranges_df.columns or 'Max Fiber Diameter' not in ranges_df.columns:
        raise ValueError("File must contain 'Min Fiber Diameter' and 'Max Fiber Diameter' columns.")
    
    # Convert the dataframe to a list of (min, max) tuples
    fiber_size_ranges = list(zip(ranges_df['Min Fiber Diameter'], ranges_df['Max Fiber Diameter']))
    
    return fiber_size_ranges

"""def create_and_save_subsets(df, fiber_size_ranges, output_file):
    
    Create subsets for each experiment and save them to an Excel file.
    
    Args:
        df (DataFrame): DataFrame containing the experiment data.
        fiber_size_ranges (list of tuples): List of (Min Fiber Diameter, Max Fiber Diameter).
        output_file (str): Path to save the Excel file with the subsets.
    
    # Initialize an Excel writer object
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        # For each experiment and each range, create a subset and save to an Excel sheet
        for exp_num in range(1, 7):  # Assuming experiments are named EXP1, EXP2, etc.
            exp_data = df.filter(regex=f'EXP{exp_num}')  # Filter columns for the current experiment
            for idx, (lower_bound, upper_bound) in enumerate(fiber_size_ranges, start=1):
                # Build the column name for fiber diameter of the current experiment
                fiber_diam_col = f'FiberDiameter_EXP{exp_num}'
                
                # Check if the column exists in the filtered data
                if fiber_diam_col in exp_data.columns:
                    # Filter for the current range within the experiment's data
                    subset_df = exp_data[(exp_data[fiber_diam_col] >= lower_bound) & (exp_data[fiber_diam_col] <= upper_bound)]
                    
                    # Define the sheet name based on the experiment number and subset index
                    sheet_name = f'EXP{exp_num}_Subset{idx}'
                    
                    # Save the filtered subset to the Excel sheet
                    subset_df.to_excel(writer, sheet_name=sheet_name, index=False)
    
    print("All subsets have been successfully saved to the Excel file.") """



def create_and_save_subsets(df, fiber_size_ranges, output_file):
    """
    Create subsets for each experiment and save them to an Excel file.
    
    Args:
        df (DataFrame): DataFrame containing the experiment data.
        fiber_size_ranges (list of tuples): List of (Min Fiber Diameter, Max Fiber Diameter).
        output_file (str): Path to save the Excel file with the subsets.
    """
    # Dynamically find the number of experiments in the DataFrame by checking the columns
    exp_columns = [col for col in df.columns if col.startswith('EXP')]
    unique_exp_numbers = sorted(set([col.split('_')[0][3:] for col in exp_columns]))

    # Initialize an Excel writer object
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        # For each experiment and each range, create a subset and save to an Excel sheet
        for exp_num in unique_exp_numbers:  # Loop through the dynamically detected experiments
            exp_data = df.filter(regex=f'EXP{exp_num}')  # Filter columns for the current experiment
            for idx, (lower_bound, upper_bound) in enumerate(fiber_size_ranges, start=1):
                # Build the column name for fiber diameter of the current experiment
                fiber_diam_col = f'FiberDiameter_EXP{exp_num}'
                
                # Check if the column exists in the filtered data
                if fiber_diam_col in exp_data.columns:
                    # Filter for the current range within the experiment's data
                    subset_df = exp_data[(exp_data[fiber_diam_col] >= lower_bound) & (exp_data[fiber_diam_col] <= upper_bound)]
                    
                    # Define the sheet name based on the experiment number and subset index
                    sheet_name = f'EXP{exp_num}_Subset{idx}'
                    
                    # Save the filtered subset to the Excel sheet
                    subset_df.to_excel(writer, sheet_name=sheet_name, index=False)
    
    print("All subsets have been successfully saved to the Excel file.")
