"""Plain-language results text and the README sheet of the statistics workbook."""
from __future__ import annotations

import pandas as pd

from . import __version__, APP_NAME, CITATION
from .processing import BIN_LABEL

README_SHEET = pd.DataFrame({"Sheet": [
    "Animal_Means", "Animal_Level_Test", "Animal_Subset_Cells", "Group_x_Subset_ANOVA",
    "Caliber_Mixed_Model", "Animal_Mixed_Model", "Diagnostics",
], "What it contains": [
    "One mean g-ratio per animal (sections equally weighted when Section IDs exist). This is the biological unit.",
    "Primary test. Two-group comparison of animal means: Student t (equal to one-way ANOVA), Welch t, exact "
    "permutation p, mean difference with 95% CI, and Hedges' g with approximate 95% CI.",
    "Mean, SD, median, quartiles and fiber count for every animal in every caliber bin; Value is the summary used by the ANOVA (mean or median).",
    "Split-plot ANOVA on animal-by-bin means (or medians, if chosen): Group between animals, Subset within animals. Greenhouse-Geisser "
    "and Huynh-Feldt corrected p for within-animal terms; partial and generalized eta squared.",
    "Per-fiber linear mixed model: g-ratio ~ Group x axon diameter, animal random intercept and slope. No bins. "
    "t tests use N animals - 2 degrees of freedom.",
    "Per-fiber model g-ratio ~ Group with an animal random intercept, accounting for correlation among fibers "
    "from the same animal. When section/slide IDs are provided, a section-within-animal random intercept is "
    "added (nested model). Section IDs are optional. Shares of variance at each level.",
    "Convergence notes and analyses that could not be run, with the reason.",
]})


def _p(p):
    return "p < 0.001" if p < 0.001 else f"p = {p:.3f}"


def results_text(results: dict, animals: pd.DataFrame, groups, settings) -> str:
    a, b = groups
    n = animals.groupby("Group")["Animal"].nunique()
    axons = animals.groupby("Group")["NAxons"].sum()
    label = BIN_LABEL[settings.bin_variable].lower()
    has_sec = animals["NSections"].notna().any()
    lines = [f"{APP_NAME} {__version__}: results summary", ""]
    lines.append("METHODS (draft text, edit before use)")
    m = (f"G-ratios were computed as axon diameter divided by fiber diameter (axon + full myelin contribution) "
         f"with {APP_NAME}. Measurements with axon diameter < {settings.min_axon:g} µm or myelin < "
         f"{settings.min_myelin:g} µm were excluded. ")
    m += ("Fibers were grouped into {k} {lab} bins of equal count defined from {ref} control fibers. "
          .format(k=settings.n_bins, lab=label,
                  ref="all pooled" if settings.reference == "pooled" else "the first"))
    m += ("Because fibers from the same animal are not independent, the animal was the experimental unit: "
          + ("fiber values were averaged within each section and sections were averaged within each animal. "
             if has_sec else "fiber values were averaged within each animal. ")
          + (f"For each animal, the mean of its bin medians was compared between {a} and {b} with a two-tailed t test,"
             if settings.cell_statistic == "median" else
             f"Animal means were compared between {a} and {b} with a two-tailed t test,")
          + " confirmed with Welch's "
          "test and an exact permutation test on animal means. To account for correlation among fibers measured "
          "from the same animal, per-fiber g-ratios were also analysed with a linear mixed-effects model with group "
          "as fixed effect and a random intercept for animal"
          + (", with a random intercept for section nested within animal" if has_sec else
             " (section identifiers were not provided, so animal IDs alone defined the random effects)")
          + ". Caliber dependence was assessed with a "
          "split-plot ANOVA (group between animals, bin within animals; Greenhouse-Geisser correction) on "
          + ("animal-by-bin medians (the median g-ratio of each animal's fibers in each bin)"
             if settings.cell_statistic == "median" else "animal-by-bin means")
          + ", and with a linear mixed model of per-fiber g-ratio on group, axon diameter and "
          "their interaction, with random intercepts and slopes for animal"
          + (" and a variance component for section within animal" if has_sec else "")
          + ", fitted by REML; fixed effects were tested on N animals - 2 degrees of freedom. "
          "Effect sizes are reported as Hedges' g and generalized eta squared.")
    lines += [m, ""]
    lines.append("RESULTS")
    lines.append(f"Biological n: {a} = {int(n.get(a, 0))} animals ({int(axons.get(a, 0))} fibers), "
                 f"{b} = {int(n.get(b, 0))} animals ({int(axons.get(b, 0))} fibers).")
    if "animal" in results:
        r = results["animal"].iloc[0]
        lines.append(
            (f"The mean of bin medians was {r.Mean_ref:.3f} ± {r.SD_ref:.3f} in {a} and {r.Mean_comp:.3f} ± "
             f"{r.SD_comp:.3f} in {b} (mean ± SD across animals); difference"
             if settings.cell_statistic == "median" else
             f"Mean g-ratio was {r.Mean_ref:.3f} ± {r.SD_ref:.3f} in {a} and {r.Mean_comp:.3f} ± {r.SD_comp:.3f} "
             f"in {b} (mean ± SD of animal means); difference")
            + f" {r.Difference_comp_minus_ref:+.3f} "
            f"(95% CI {r.CI95_low_Student:+.3f} to {r.CI95_high_Student:+.3f}), t({r.df_Student:.0f}) = "
            f"{r.t_Student:.2f}, {_p(r.p_Student)}; Welch {_p(r.p_Welch)}; permutation p = {r.p_permutation:.3g}; "
            f"Hedges' g = {r.Hedges_g:.2f} (approx. 95% CI {r.Hedges_g_CI95_low:.2f} to {r.Hedges_g_CI95_high:.2f}).")
        if r.Smallest_possible_permutation_p > 0.05:
            lines.append(
                f"Note: with {r.N_animals_ref} and {r.N_animals_comp} animals the smallest permutation p that "
                f"can occur is {r.Smallest_possible_permutation_p:.3g}, so the permutation test cannot reach "
                "0.05 at this sample size. The parametric p relies on approximate normality of animal means.")
    if "anova" in results:
        t = results["anova"].set_index("Effect")
        for eff in ("Group", "Subset", "Group x Subset"):
            r = t.loc[eff]
            pcol = r.p_uncorrected if eff == "Group" else r.p_GG
            corr = "" if eff == "Group" else f", GG epsilon = {r.GG_epsilon:.2f}"
            lines.append(f"Split-plot ANOVA, {eff}: F({r.df_num:.0f}, {r.df_den:.0f}) = {r.F:.2f}, {_p(pcol)}"
                         f"{corr}, generalized eta² = {r.generalized_eta2:.3f}.")
    if "caliber" in results:
        for r in results["caliber"].itertuples():
            lines.append(f"Caliber model, {r.Term}: {r.Estimate:+.4f} (95% CI {r.CI95_low:+.4f} to "
                         f"{r.CI95_high:+.4f}), t({r.df}) = {r.t:.2f}, {_p(r.p)}.")
    if "mixed" in results:
        r = results["mixed"].iloc[0]
        shares = (f"animal {r.Share_animal:.0%}, section {r.Share_section:.0%}, fiber {r.Share_axon:.0%}"
                  if r.Nested else f"animal {r.Share_animal:.0%}, fiber {r.Share_axon:.0%}")
        lines.append(f"Animal mixed model ({r.Structure}), {r.Term}: {r.Estimate:+.4f} (95% CI {r.CI95_low:+.4f} "
                     f"to {r.CI95_high:+.4f}), t({r.df}) = {r.t:.2f}, {_p(r.p)}. Variance shares: {shares}.")
    lines += ["", "Please cite: " + CITATION, ""]
    return "\n".join(lines)
