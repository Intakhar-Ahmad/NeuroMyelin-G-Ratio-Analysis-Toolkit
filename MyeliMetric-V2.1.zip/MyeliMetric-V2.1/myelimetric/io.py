"""Input readers.

Two layouts are accepted and both are converted to one tidy table with one row
per axon:

* Wide (published layout): one file per group, paired columns ``<ID>_Ax`` and
  ``<ID>_My`` for every animal, e.g. ``CTL1_Ax, CTL1_My, CTL2_Ax, ...``. An
  optional section/slide ID column (e.g. ``Slide-ID``) may follow each pair.
* Long: one file holding both groups with columns ``Group, Animal, Ax, My``
  and optionally ``Section`` (histological section / field within animal).

Tidy columns: Group, Animal, Section (may be absent), SourceRow, Ax, My.
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd

PAIR_RE = re.compile(r"^\s*(.+?)_(ax|my)\s*$", re.IGNORECASE)
LONG_REQUIRED = {"group", "animal", "ax", "my"}


class InputError(ValueError):
    """Raised for problems the user can fix in the input file."""


def read_table(path) -> pd.DataFrame:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in (".xlsx", ".xlsm", ".xls"):
        return pd.read_excel(path, sheet_name=0)
    raise InputError(f"Unsupported file type '{suffix}'. Use .xlsx, .xls or .csv.")


def is_long_format(table: pd.DataFrame) -> bool:
    cols = {str(c).strip().lower() for c in table.columns}
    return LONG_REQUIRED.issubset(cols)


def detect_pairs(table: pd.DataFrame) -> dict[str, dict[str, str]]:
    """Return {sample_id: {'ax': column, 'my': column}} preserving file order."""
    pairs: dict[str, dict[str, str]] = {}
    for col in table.columns:
        m = PAIR_RE.match(str(col))
        if m:
            sid = m.group(1).strip()
            pairs.setdefault(sid, {})[m.group(2).lower()] = col
    if not pairs:
        raise InputError(
            "No valid column pairs were found. Every animal needs <ID>_Ax and <ID>_My "
            "columns with exactly the same identifier, for example CTL1_Ax and CTL1_My."
        )
    broken = [sid for sid, p in pairs.items() if set(p) != {"ax", "my"}]
    if broken:
        raise InputError(
            "These identifiers have only one of _Ax / _My: " + ", ".join(broken)
            + ". Check the spelling of the column headers."
        )
    return pairs


def _numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").astype(float)


SECTION_NAMES = {"slideid", "slide", "section", "sectionid", "slice", "sliceid", "field", "fieldid",
                 "image", "imageid", "grid", "gridid"}


def _section_key(name) -> str:
    """'Slide-ID.2' -> 'slideid'; 'CTL1_Section' -> 'section' (pandas adds .N to repeated headers)."""
    base = re.sub(r"\.\d+$", "", str(name).strip())
    return re.sub(r"[\s_\-]", "", base).lower()


def find_section_columns(table: pd.DataFrame, pairs) -> dict[str, str]:
    """Locate an optional section/slide ID column for each animal in the wide layout.

    Accepted: a column named <ID>_Section / <ID>_Slide (etc.) anywhere, or a column
    named Slide-ID / Section / Slide (etc.) placed after the animal's _Ax/_My pair and
    before the next animal's columns.
    """
    cols = list(table.columns)
    pair_pos = sorted((max(cols.index(p["ax"]), cols.index(p["my"])), sid) for sid, p in pairs.items())
    first_pos = sorted(min(cols.index(p["ax"]), cols.index(p["my"])) for p in pairs.values())
    found = {}
    for sid in pairs:
        for c in cols:
            m = re.match(rf"^\s*{re.escape(sid)}_(.+)$", str(c), re.I)
            if m and _section_key(m.group(1)) in SECTION_NAMES:
                found[sid] = c
    for end, sid in pair_pos:
        if sid in found:
            continue
        nxt = min([f for f in first_pos if f > end], default=len(cols))
        for c in cols[end + 1:nxt]:
            if _section_key(c) in SECTION_NAMES:
                found[sid] = c
                break
    return found


def wide_to_tidy(table: pd.DataFrame, group: str) -> pd.DataFrame:
    pairs = detect_pairs(table)
    sections = find_section_columns(table, pairs)
    if sections and len(sections) != len(pairs):
        missing = [sid for sid in pairs if sid not in sections]
        raise InputError("Section/slide IDs were found for some animals but not for: " + ", ".join(missing)
                         + ". Give every animal a Slide-ID column, or remove them all to analyse by animal only.")
    frames = []
    for sid, p in pairs.items():
        ax = _numeric(table[p["ax"]])
        my = _numeric(table[p["my"]])
        keep = ax.notna() | my.notna()          # fully empty rows are padding, not data
        frame = pd.DataFrame({
            "Group": group,
            "Animal": sid,
            "SourceRow": np.arange(len(table))[keep.to_numpy()] + 2,  # Excel row number
            "Ax": ax[keep].to_numpy(),
            "My": my[keep].to_numpy(),
        })
        if sections:
            sec = table.loc[keep, sections[sid]]
            empty = sec.isna() | (sec.astype(str).str.strip() == "")
            if empty.any():
                rows = (np.flatnonzero(keep.to_numpy())[empty.to_numpy()] + 2)[:5]
                raise InputError(f"{sid}: {int(empty.sum())} measurement rows have no section/slide ID "
                                 f"(Excel rows {', '.join(map(str, rows))}...).")
            frame["Section"] = sec.astype(str).str.strip().str.replace(r"\.0$", "", regex=True).to_numpy()
        frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def long_to_tidy(table: pd.DataFrame) -> pd.DataFrame:
    rename = {}
    for c in table.columns:
        key = str(c).strip().lower()
        if key in ("group", "animal", "section", "ax", "my"):
            rename[c] = key.capitalize() if key not in ("ax", "my") else key.capitalize()
    t = table.rename(columns=rename)
    missing = {"Group", "Animal", "Ax", "My"} - set(t.columns)
    if missing:
        raise InputError("Long-format table is missing columns: " + ", ".join(sorted(missing)))
    out = pd.DataFrame({
        "Group": t["Group"].astype(str).str.strip(),
        "Animal": t["Animal"].astype(str).str.strip(),
        "SourceRow": np.arange(len(t)) + 2,
        "Ax": _numeric(t["Ax"]),
        "My": _numeric(t["My"]),
    })
    if "Section" in t.columns:
        sec = t["Section"]
        if sec.isna().any() or (sec.astype(str).str.strip() == "").any():
            raise InputError("Section column is present but some rows have no Section ID.")
        out["Section"] = sec.astype(str).str.strip()
    bad = (out["Group"].isin(["", "nan"])) | (out["Animal"].isin(["", "nan"]))
    if bad.any():
        raise InputError(f"{int(bad.sum())} rows have an empty Group or Animal ID.")
    out = out[out["Ax"].notna() | out["My"].notna()].reset_index(drop=True)
    return out


def load_group_file(path, group: str) -> tuple[pd.DataFrame, str]:
    """Load a wide file for one group, or a long file. Returns (tidy, layout)."""
    table = read_table(path)
    if is_long_format(table):
        return long_to_tidy(table), "long"
    return wide_to_tidy(table, group), "wide"
