"""Computational core: exclusion, fiber diameter, g-ratio, caliber bins.

Definitions are unchanged from the published MyeliMetric workflow:
    fiber diameter = Ax + My      (My is the full myelin contribution, 2 x radial thickness)
    g-ratio        = Ax / (Ax + My)
By default fiber diameter and g-ratio are rounded to 2 decimals exactly as in
V1/V2, so descriptive results are identical to V2; precision="full" keeps all digits.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field

import numpy as np
import pandas as pd


@dataclass
class Settings:
    min_axon: float = 0.15            # um; axons below are excluded
    min_myelin: float = 0.03          # um; myelin values below are excluded
    n_bins: int = 6
    bin_variable: str = "fiber"       # "fiber" (published) or "axon"
    reference: str = "pooled"         # "pooled" (V2 default) or "first" (published V1)
    make_histograms: bool = True
    animals_confirmed: bool = False   # numbered columns are distinct, independent animals
    precision: str = "v2"             # "v2": fiber diameter and g-ratio rounded to 2 decimals, as in V1/V2
    cell_statistic: str = "mean"      # summary of each animal x bin cell for the nested ANOVA: "mean" or "median"

    DEFAULTS = None  # filled below

    def validate(self):
        if not (self.min_axon >= 0 and self.min_myelin >= 0):
            raise ValueError("Thresholds must be zero or positive.")
        if not (1 <= int(self.n_bins) <= 30):
            raise ValueError("Number of bins must be between 1 and 30.")
        if self.bin_variable not in ("fiber", "axon"):
            raise ValueError("bin_variable must be 'fiber' or 'axon'.")
        if self.cell_statistic not in ("mean", "median"):
            raise ValueError("cell_statistic must be 'mean' or 'median'.")
        if self.precision not in ("v2", "full"):
            raise ValueError("precision must be 'v2' or 'full'.")
        if self.reference not in ("pooled", "first"):
            raise ValueError("reference must be 'pooled' or 'first'.")
        self.n_bins = int(self.n_bins)
        return self

    def to_dict(self):
        d = asdict(self)
        d.pop("DEFAULTS", None)
        return d


Settings.DEFAULTS = Settings()

BIN_COLUMN = {"fiber": "FiberDiameter", "axon": "AxonDiameter"}
BIN_LABEL = {"fiber": "Fiber diameter", "axon": "Axon diameter"}


def clean_and_compute(tidy: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    """Add FiberDiameter, AxonDiameter, GRatio and an ExclusionReason column.

    Rows are never dropped here, so the exclusion audit can list every axon.
    """
    d = tidy.copy()
    reason = pd.Series("", index=d.index, dtype=object)
    reason[d["Ax"].isna() | d["My"].isna()] = "incomplete pair (Ax or My missing)"
    ok = reason == ""
    reason[ok & (d["Ax"] < settings.min_axon)] = f"axon < {settings.min_axon:g} um"
    ok = reason == ""
    reason[ok & (d["My"] < settings.min_myelin)] = f"myelin < {settings.min_myelin:g} um"
    # Rounding to 9 decimals only removes floating-point noise (0.42 + 0.23 = 0.6500000000000001),
    # so that equal measurements fall in the same bin; it does not reduce measurement precision.
    d["FiberDiameter"] = (d["Ax"] + d["My"]).round(9)
    d["AxonDiameter"] = d["Ax"]
    with np.errstate(divide="ignore", invalid="ignore"):
        d["GRatio"] = d["Ax"] / d["FiberDiameter"]
    if settings.precision == "v2":
        # Same as the published V1/V2 core: values rounded to 2 decimals before binning and statistics.
        d["FiberDiameter"] = d["FiberDiameter"].round(2)
        d["GRatio"] = d["GRatio"].round(2)
    ok = reason == ""
    reason[ok & ~np.isfinite(d["GRatio"])] = "g-ratio not computable"
    d["ExclusionReason"] = reason
    d["Included"] = reason == ""
    return d


def equal_count_ranges(values: np.ndarray, n_bins: int) -> pd.DataFrame:
    """Split sorted reference values into equal-count chunks (published method).

    Chunk size = ceil(n / k); the last chunk takes the remainder. Bin k covers
    [lower_k, lower_{k+1}) so that bins are contiguous and no fiber falls in a
    gap between the observed max of one chunk and the min of the next. The last
    bin is closed at the reference maximum.
    """
    v = np.sort(np.asarray(values, float))
    v = v[np.isfinite(v)]
    n = len(v)
    if n < n_bins:
        raise ValueError(f"Only {n} control fibers for {n_bins} bins; reduce the number of bins.")
    size = int(np.ceil(n / n_bins))
    rows = []
    for i in range(n_bins):
        start = i * size if i < n_bins - 1 else size * (n_bins - 1)
        stop = start + size if i < n_bins - 1 else n
        chunk = v[start:stop]
        if len(chunk) == 0:
            raise ValueError("Too many bins for the number of control fibers; reduce the number of bins.")
        rows.append((chunk.min(), chunk.max(), len(chunk)))
    lowers = [r[0] for r in rows]
    out = []
    for i, (lo, hi, cnt) in enumerate(rows):
        upper = lowers[i + 1] if i < n_bins - 1 else hi
        out.append({"Subset": i + 1, "Min": lo, "Max": hi,
                    "LowerEdge": lo, "UpperEdge": upper, "LowerInclusive": True,
                    "UpperInclusive": i == n_bins - 1, "ReferenceCount": cnt})
    return pd.DataFrame(out)


def pooled_quantile_ranges(values: np.ndarray, n_bins: int, round2: bool) -> pd.DataFrame:
    """MyeliMetric-V2 pooled-control bins.

    Bin edges are the k/n quantiles (linear interpolation) of all pooled control fibers,
    rounded to 2 decimals as in V2. Bin k holds values > edge_(k-1) and <= edge_k; the
    first bin starts at the smallest control value. Bins are therefore contiguous, and
    tied values always fall in the same bin.
    """
    v = np.sort(np.asarray(values, float))
    v = v[np.isfinite(v)]
    if len(v) < n_bins:
        raise ValueError(f"Only {len(v)} control fibers for {n_bins} bins; reduce the number of bins.")
    edges = np.quantile(v, [k / n_bins for k in range(n_bins + 1)])
    if round2:
        edges = np.round(edges, 2)
    edges[0], edges[-1] = v.min(), v.max()
    if np.any(np.diff(edges) <= 0):
        raise ValueError("Too many bins for these control values (two bin edges coincide); reduce the number of bins.")
    out = []
    for i in range(n_bins):
        lo, hi = edges[i], edges[i + 1]
        inside = ((v >= lo) if i == 0 else (v > lo)) & (v <= hi)
        out.append({"Subset": i + 1, "Min": v[inside].min() if inside.any() else lo,
                    "Max": v[inside].max() if inside.any() else hi,
                    "LowerEdge": lo, "UpperEdge": hi, "LowerInclusive": i == 0,
                    "UpperInclusive": True, "ReferenceCount": int(inside.sum())})
    return pd.DataFrame(out)


def reference_ranges(ctl: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    col = BIN_COLUMN[settings.bin_variable]
    inc = ctl[ctl["Included"]]
    if settings.reference == "first":
        # Published V1: equal-count chunks of the first control animal.
        first = inc["Animal"].iloc[0] if len(inc) else None
        inc = inc[inc["Animal"] == first]
        return equal_count_ranges(inc[col].to_numpy(), settings.n_bins)
    return pooled_quantile_ranges(inc[col].to_numpy(), settings.n_bins, settings.precision == "v2")


def assign_subsets(d: pd.DataFrame, ranges: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    col = BIN_COLUMN[settings.bin_variable]
    d = d.copy()
    x = d[col].to_numpy(float)
    subset = np.full(len(d), np.nan)
    for r in ranges.itertuples():
        tol = 1e-9
        above = (x >= r.LowerEdge - tol) if r.LowerInclusive else (x > r.LowerEdge + tol)
        below = (x <= r.UpperEdge + tol) if r.UpperInclusive else (x < r.UpperEdge - tol)
        inside = above & below
        subset[inside & np.isnan(subset)] = r.Subset
    d["Subset"] = subset
    lo, hi = ranges["LowerEdge"].min(), ranges["UpperEdge"].max()
    outside = d["Included"] & np.isnan(subset)
    d.loc[outside & (d[col] < lo), "ExclusionReason"] = "below control bin range"
    d.loc[outside & (d[col] > hi), "ExclusionReason"] = "above control bin range"
    d["InSubset"] = d["Included"] & ~np.isnan(subset)
    return d


def exclusion_audit(d: pd.DataFrame) -> pd.DataFrame:
    cols = ["Group", "Animal"] + (["Section"] if "Section" in d.columns else [])
    counts = d.groupby(cols, sort=False).agg(
        RowsRead=("Ax", "size"), Included=("Included", "sum"),
        InSubsets=("InSubset", "sum") if "InSubset" in d.columns else ("Included", "sum"),
    ).reset_index()
    reasons = (d[d["ExclusionReason"] != ""]
               .groupby(cols + ["ExclusionReason"], sort=False).size()
               .unstack(fill_value=0).reset_index())
    out = counts.merge(reasons, on=cols, how="left").fillna(0)
    for c in out.columns[len(cols):]:
        out[c] = out[c].astype(int)
    return out
