"""Figures. All functions write PNG files and close their figures."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

COLORS = {0: "#2E73B8", 1: "#C0552B"}   # V2 colours: CTL blue, EXP orange
MARKERS = {0: "o", 1: "s"}


def _group_style(groups):
    return {g: (COLORS.get(i, "gray"), MARKERS.get(i, "^")) for i, g in enumerate(groups)}


# ---------------------------------------------------------------------------------------
# Descriptive figures: identical layout and styling to MyeliMetric-V2 (and the published V1)
# ---------------------------------------------------------------------------------------
def scatter_plot(d: pd.DataFrame, animal: str, path: Path):
    v = d[(d["Animal"] == animal) & d["Included"]]
    plt.figure(figsize=(10, 8))
    plt.scatter(v["FiberDiameter"], v["AxonDiameter"], alpha=0.6, s=50)
    if len(v) > 1:
        slope, intercept = np.polyfit(v["FiberDiameter"], v["AxonDiameter"], 1)
        x_line = np.linspace(v["FiberDiameter"].min(), v["FiberDiameter"].max(), 100)
        plt.plot(x_line, slope * x_line + intercept, "r-", linewidth=2)
        plt.text(0.05, 0.95, f"y = {slope:.3f}x + {intercept:.3f}", transform=plt.gca().transAxes,
                 fontsize=12, verticalalignment="top",
                 bbox=dict(boxstyle="round", facecolor="white", alpha=0.8))
    plt.title(f"Scatter Plot: {animal} Fiber Diameter vs. Axon Diameter", fontsize=14)
    plt.xlabel("Fiber Diameter (μm)", fontsize=12)
    plt.ylabel("Axon Diameter (μm)", fontsize=12)
    plt.grid(True, alpha=0.3)
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def histogram(values: np.ndarray, title: str, path: Path):
    values = np.asarray(values, float)
    if len(values) < 3:
        return False
    # Display only: values are shown at 2 decimals as in V2, so the histogram looks the same.
    shown = np.round(values, 2)
    freq, bins = np.histogram(shown, bins="auto", range=(0, 1))
    freq = freq.astype(float) / freq.sum()
    plt.figure(figsize=(10, 6))
    bars = plt.bar(bins[:-1], freq, width=np.diff(bins), align="edge", color="blue", edgecolor="black")
    for bar in bars:
        h = bar.get_height()
        if h > 0:
            plt.gca().annotate(f"{h:.1%}", xy=(bar.get_x() + bar.get_width() / 2, h), xytext=(0, 3),
                               textcoords="offset points", ha="center", va="bottom", rotation=90)
    plt.title(f"Frequency Distribution of G Ratios - {title}")
    plt.xlabel("G Ratio Bin")
    plt.ylabel("Frequency (%)")
    plt.ylim(0, max(freq) * 1.2)
    plt.savefig(path)
    plt.close()
    return True


def normality_overview(stats: pd.DataFrame, title: str, path: Path, tag: str = ""):
    if stats.empty:
        return
    fig, ax = plt.subplots(figsize=(11, 6))
    ax.bar(stats["EXP_name"], stats["Shapiro-p-value"], edgecolor="black", facecolor="none", linewidth=1.5)
    ax.axhline(0.05, color="red", linestyle="--", label="p = 0.05 threshold")
    ax.set_ylabel("Shapiro-Wilk p-value")
    ax.set_xlabel("Fiber diameter subset")
    ax.set_title(f"Normality test (Shapiro-Wilk) by fiber diameter subset ({tag})" if tag else title)
    ax.set_xticks(range(len(stats)))
    ax.set_xticklabels(stats["EXP_name"], rotation=45, ha="right")
    ax.legend()
    ax.grid(False)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def summary_plot(cells: pd.DataFrame, ranges: pd.DataFrame, groups, bin_label: str, path: Path):
    """V2 Summary_CTL_vs_EXP.png: each marker is an animal-specific subset mean, error bars are the
    within-subset g-ratio SD, dashed lines are the grand mean of the animal-subset means."""
    style = _group_style(groups)
    fig, ax = plt.subplots(figsize=(10, 6))
    for g in groups:
        color, marker = style[g]
        sub = cells[cells["Group"] == g]
        ax.axhline(sub["Mean"].mean(), color=color, linestyle="--", linewidth=1.2,
                   label=f"{g} grand mean = {sub['Mean'].mean():.3f}")
    for g in groups:
        color, marker = style[g]
        sub = cells[cells["Group"] == g]
        ax.errorbar(sub["Subset"], sub["Mean"], yerr=sub["SD"], fmt=marker, color=color, ecolor=color,
                    capsize=4, markersize=7, alpha=0.9, linestyle="none", label=f"{g} (per subset)")
    ax.set_xticks(sorted(ranges["Subset"].astype(int)))
    ax.set_xlabel(f"{bin_label} subset (small to large)")
    ax.set_ylabel("Mean g-ratio")
    ax.set_title(f"Per-subset mean g-ratio: {groups[0]} vs {groups[1]}")
    ax.grid(True, alpha=0.3)
    ax.legend(loc="upper right", fontsize=9)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


# ---------------------------------------------------------------------------------------
# Statistics figures (new in 2.1), saved in Summary/Statistics
# ---------------------------------------------------------------------------------------
def animal_subset_plot(cells: pd.DataFrame, ranges: pd.DataFrame, groups, bin_label: str, path: Path,
                       anova_text: str | None = None):
    """Every animal shown separately in every bin, at the bin's upper edge (µm); error bars are the
    within-animal SD; dashed lines are each group's grand mean of animal-by-subset means.
    Statistical results are reported in Nested_ANOVA_Results.xlsx, not on the figure."""
    colors = {g: ("#1f4e9c", "#c0392b")[i] if i < 2 else "gray" for i, g in enumerate(groups)}
    markers = {g: ("o", "s")[i] if i < 2 else "^" for i, g in enumerate(groups)}
    x_of = dict(zip(ranges["Subset"].astype(int), ranges["UpperEdge"]))
    width = (ranges["UpperEdge"].max() - ranges["LowerEdge"].min()) * 0.012
    med = "Statistic" in cells.columns and cells["Statistic"].iloc[0] == "median"
    fig, ax = plt.subplots(figsize=(10, 7))
    for gi, g in enumerate(groups):
        sub = cells[cells["Group"] == g]
        animals = list(dict.fromkeys(sub["Animal"]))
        for ai, a in enumerate(animals):
            s = sub[sub["Animal"] == a]
            off = (gi - 0.5) * width * 3 + (ai - (len(animals) - 1) / 2) * width
            if med:
                err = np.vstack([(s["Value"] - s["Q1"]).clip(lower=0), (s["Q3"] - s["Value"]).clip(lower=0)])
            else:
                err = s["SD"]
            ax.errorbar([x_of[int(k)] + off for k in s["Subset"]], s["Value"], yerr=err, fmt=markers[g],
                        color=colors[g], ms=8, capsize=3, lw=1.2, label=g if ai == 0 else None)
        ax.axhline(sub["Value"].mean(), color=colors[g], ls="--", lw=2,
                   label=f"{g} grand mean{' of medians' if med else ''} = {sub['Value'].mean():.3f}")
    ax.set_xticks(list(x_of.values()))
    ax.set_xticklabels([f"{v:.2f}" for v in x_of.values()], rotation=45)
    ax.tick_params(axis="both", labelsize=16)
    ax.set_xlabel(f"Upper edge of control {bin_label.lower()} bin (µm)", fontsize=18)
    ax.set_ylabel("Median g-ratio (IQR)" if med else "Mean g-ratio", fontsize=18)
    ax.set_title(f"{groups[0]} vs {groups[1]}: animal-by-subset {'median' if med else 'mean'} g-ratio",
                 fontsize=19)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    leg = ax.legend(title="Group", frameon=False, fontsize=14, title_fontsize=15)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def animal_plot(animals: pd.DataFrame, groups, path: Path, ylabel="Mean g-ratio per animal"):
    style = _group_style(groups)
    fig, ax = plt.subplots(figsize=(4.8, 5))
    for i, g in enumerate(groups):
        v = animals.loc[animals["Group"] == g, "MeanGRatio"].to_numpy(float)
        off = np.linspace(-0.08, 0.08, len(v)) if len(v) > 1 else [0]
        ax.scatter(i + np.asarray(off), v, s=60, facecolors="white", edgecolors=style[g][0], lw=1.6, zorder=3)
        sem = v.std(ddof=1) / np.sqrt(len(v)) if len(v) > 1 else 0
        ax.errorbar(i, v.mean(), yerr=sem, fmt="_", ms=26, capsize=8, color="black", zorder=4)
    ax.set_xticks(range(len(groups)), groups)
    ax.set_xlim(-0.6, len(groups) - 0.4)
    ax.set_ylabel(ylabel)
    ax.set_title("Each point is one animal\n(bar: mean ± SEM)", fontsize=10)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def caliber_plot(d: pd.DataFrame, fit: dict | None, groups, path: Path):
    """g-ratio vs axon diameter, per-animal lines, and fitted group lines."""
    style = _group_style(groups)
    fig, ax = plt.subplots(figsize=(7, 5.5))
    for g in groups:
        sub = d[d["Group"] == g]
        ax.scatter(sub["AxonDiameter"], sub["GRatio"], s=8, alpha=0.25, color=style[g][0])
    if fit:
        xs = np.linspace(d["AxonDiameter"].quantile(0.01), d["AxonDiameter"].quantile(0.99), 50)
        for g in groups:
            b0, b1 = fit["lines"][g]
            ax.plot(xs, b0 + b1 * (xs - fit["center"]), color=style[g][0], lw=2.5,
                    label=f"{g}: slope {b1:.3f} per µm")
        ax.legend(frameon=False)
    ax.set_xlabel("Axon diameter (µm)")
    ax.set_ylabel("G-ratio")
    ax.set_title("G-ratio vs axon caliber (mixed model, animal random effects)", fontsize=10)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def grand_mean_plot(cells: pd.DataFrame, groups, path: Path, p_text: str | None = None):
    """Grand mean g-ratio per group (mean of animal-by-subset means, as in V2), with each
    animal's own grand mean shown as a point and mean +/- SEM across animals."""
    style = _group_style(groups)
    per_animal = cells.groupby(["Group", "Animal"], sort=False)["Value"].mean().reset_index()
    fig, ax = plt.subplots(figsize=(6, 6.5))
    p_text = None  # statistics are reported in Nested_ANOVA_Results.xlsx
    tops = []
    for i, g in enumerate(groups):
        v = per_animal.loc[per_animal["Group"] == g, "Value"].to_numpy(float)
        grand = cells.loc[cells["Group"] == g, "Value"].mean()
        sem = v.std(ddof=1) / np.sqrt(len(v)) if len(v) > 1 else 0
        ax.hlines(grand, i - 0.25, i + 0.25, color=style[g][0], lw=3, zorder=2)
        ax.errorbar(i, grand, yerr=sem, color="black", capsize=8, lw=1.5, zorder=4)
        off = np.linspace(-0.12, 0.12, len(v)) if len(v) > 1 else [0]
        ax.scatter(i + np.asarray(off), v, s=80, color=style[g][0], zorder=3)
        ax.text(i + 0.3, grand, f"{grand:.3f}", ha="left", va="center", fontsize=16)
        tops.append(max(v.max(), grand + sem))
    lo = min(per_animal["Value"].min(), cells["Value"].min()) - 0.05
    hi = max(tops) + 0.04
    if p_text:
        y = max(tops) + 0.018
        ax.plot([0, 0, 1, 1], [y - 0.004, y, y, y - 0.004], color="black", lw=1)
        ax.text(0.5, y + 0.003, p_text, ha="center", va="bottom", fontsize=9)
        hi = y + 0.025
    ax.set_ylim(max(0, lo), min(1, hi))
    ax.set_xticks(range(len(groups)), groups)
    ax.set_xlim(-0.6, len(groups) - 0.2)
    med = "Statistic" in cells.columns and cells["Statistic"].iloc[0] == "median"
    ax.set_ylabel("Grand mean of bin medians" if med else "Grand mean g-ratio", fontsize=18)
    ax.tick_params(axis="both", labelsize=16)
    ax.set_title("Grand mean g-ratio\n(points: animals; line: group mean ± SEM)", fontsize=16)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)
