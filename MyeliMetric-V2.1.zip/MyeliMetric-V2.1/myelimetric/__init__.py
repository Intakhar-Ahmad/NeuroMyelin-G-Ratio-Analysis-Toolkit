"""MyeliMetric-2.1: standardized g-ratio analysis with animal-level statistics."""

__version__ = "2.1.0"
APP_NAME = "MyeliMetric-2.1"
CITATION = (
    "Ahmad I, Chowdhury FS, Boullerne AI, Gow A, Feinstein DL. MyeliMetric: A Python-Based "
    "Toolbox for Standardized G-Ratio Analysis of Axon-Myelin Integrity. ASN Neuro. "
    "2025;18(1):2603411. doi:10.1080/17590914.2025.2603411"
)
