"""Standard workflow: load CTL, load EXP, Analyze.

Output layout (one save location chosen by the user):

    <save>/Control/{Cleaned,Subsets,Stats,Histograms,ScatterPlots,Figures}, run_log_CTL.txt
    <save>/Experimental/... same, using the control-derived bin ranges
    <save>/Summary/Summary_Report.xlsx, Summary_CTL_vs_EXP.png, Exclusion_Audit.xlsx
    <save>/Summary/Statistics/Statistics_Report.xlsx, Results_Summary.txt, figures
    <save>/MyeliMetric_run_log.txt, settings.json
"""
from __future__ import annotations

import datetime as _dt
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats as st

from . import __version__, APP_NAME, CITATION
from . import io, processing as proc, stats as ms, figures as fig
from .report import results_text, README_SHEET

MARKER = ".myelimetric_output"
FOLDERS = ("Control", "Experimental", "Summary")


class Logger:
    def __init__(self, callback=None):
        self.callback = callback or print
        self.lines: list[str] = []

    def __call__(self, msg: str):
        line = f"[{_dt.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
        self.lines.append(line)
        self.callback(line)

    def write(self, path: Path, start: int = 0):
        Path(path).write_text("\n".join(self.lines[start:]) + "\n", encoding="utf-8")


def _xlsx(path: Path, sheets: dict[str, pd.DataFrame]):
    with pd.ExcelWriter(path, engine="openpyxl") as w:
        for name, df in sheets.items():
            df.to_excel(w, sheet_name=name[:31], index=False)


def _p(pv):
    return "< 0.001" if pv < 0.001 else f"{pv:.3f}"


def write_nested_anova_workbook(path: Path, stats_res: dict, cells: pd.DataFrame, groups, ranges,
                                bin_label: str):
    """Readable workbook of the nested (animal-level) analysis results."""
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter
    a = stats_res["anova"].set_index("Effect")
    rows = []
    for eff, label in (("Group", "Group (between animals)"), ("Subset", "Bin (within animals)"),
                       ("Group x Subset", "Group x Bin (within animals)")):
        r = a.loc[eff]
        within = eff != "Group"
        rows.append({
            "Effect": label, "Tested against": "between-animal variation" if not within else "within-animal variation",
            "F": round(r.F, 3), "df (effect)": int(r.df_num), "df (error)": int(r.df_den),
            "p": _p(r.p_uncorrected),
            "GG epsilon": round(r.GG_epsilon, 3) if within else "",
            "p (Greenhouse-Geisser)": _p(r.p_GG) if within else "",
            "HF epsilon": round(r.HF_epsilon, 3) if within else "",
            "p (Huynh-Feldt)": _p(r.p_HF) if within else "",
            "Partial eta squared": round(r.partial_eta2, 3), "Generalized eta squared": round(r.generalized_eta2, 3),
        })
    anova = pd.DataFrame(rows)
    mixed = []
    if "mixed" in stats_res:
        m = stats_res["mixed"].iloc[0]
        mixed.append({"Model": "Animal mixed model", "Random effects": m.Structure,
                      "Group difference": round(m.Estimate, 4), "95% CI low": round(m.CI95_low, 4),
                      "95% CI high": round(m.CI95_high, 4), "t": round(m.t, 3), "df": int(m.df), "p": _p(m.p),
                      "Animals": int(m.N_animals),
                      "Sections": "" if pd.isna(m.N_sections) else int(m.N_sections), "Fibers": int(m.N_axons),
                      "Variance share: animal": round(m.Share_animal, 4),
                      "Variance share: section": "" if pd.isna(m.Share_section) else round(m.Share_section, 4),
                      "Variance share: fiber": round(m.Share_axon, 4)})
    mixed = pd.DataFrame(mixed)
    stat = str(cells["Statistic"].iloc[0]) if "Statistic" in cells.columns else "mean"
    means = cells.pivot_table(index=["Group", "Animal"], columns="Subset", values="Value", sort=False)
    lab = bin_label.title()
    means.columns = [f"Bin {int(k)} (<= {ranges.set_index('Subset').loc[k, 'UpperEdge']:.2f} um)" for k in means.columns]
    means = means.round(4).reset_index()
    means["Animal mean" if stat == "mean" else "Animal mean of medians"] = means.iloc[:, 2:].mean(axis=1).round(4)
    gm = cells.groupby("Group", sort=False)["Value"].mean()
    info = pd.DataFrame({"Item": [
        "Design", "Experimental unit", "Cell summary", "Groups", "Animals per group", "Bins",
        "Grand mean g-ratio" if stat == "mean" else "Grand mean of medians",
        "Group test", "Bin and Group x Bin tests", "Mixed model", "Note"], "Value": [
        f"Split-plot (nested) ANOVA on animal-by-bin {stat} g-ratios; {lab.lower()} bins from pooled controls",
        f"Animal (fibers are summarized within each animal and bin)",
        ("Median of each animal's fibers in each bin (as in the Prism workflow)" if stat == "median"
         else "Mean of each animal's fibers in each bin"),
        f"{groups[0]} (reference), {groups[1]}",
        ", ".join(f"{g} = {cells.loc[cells.Group == g, 'Animal'].nunique()}" for g in groups),
        str(len(ranges)),
        ", ".join(f"{g} = {gm[g]:.4f}" for g in groups),
        "F against between-animal variation (animals within groups)",
        "F against within-animal variation, with Greenhouse-Geisser and Huynh-Feldt corrections",
        "Per-fiber g-ratio ~ Group, random intercept for animal (plus section within animal when slide IDs are given); t on N animals - 2 df",
        "p values below 0.001 are shown as < 0.001; exact values are in Statistics_Report.xlsx"]})
    with pd.ExcelWriter(path, engine="openpyxl") as w:
        info.to_excel(w, sheet_name="About", index=False)
        anova.to_excel(w, sheet_name="Nested_ANOVA", index=False)
        if len(mixed):
            mixed.to_excel(w, sheet_name="Mixed_Model", index=False)
        means.to_excel(w, sheet_name="Animal_x_Bin_Means" if stat == "mean" else "Animal_x_Bin_Medians", index=False)
        head = PatternFill("solid", fgColor="1F2D3D")
        thin = Side(style="thin", color="BFC8D2")
        for ws in w.book.worksheets:
            for c in ws[1]:
                c.font = Font(bold=True, color="FFFFFF")
                c.fill = head
                c.alignment = Alignment(wrap_text=True, vertical="center")
            for row in ws.iter_rows(min_row=1):
                for c in row:
                    c.border = Border(top=thin, bottom=thin, left=thin, right=thin)
                    if c.row > 1:
                        c.alignment = Alignment(wrap_text=True, vertical="top")
            for i, col in enumerate(ws.columns, 1):
                width = max(len(str(c.value)) if c.value is not None else 0 for c in col)
                ws.column_dimensions[get_column_letter(i)].width = min(max(12, width + 2), 70)
            ws.freeze_panes = "A2"


def _sheet_name(animal, k):
    name = f"{animal}_Subset{k}"
    return name if len(name) <= 31 else f"{animal[:31 - len(f'_Subset{k}')]}_Subset{k}"


def prepare_output(save_dir: Path, log: Logger):
    save_dir = Path(save_dir)
    if not save_dir.exists():
        save_dir.mkdir(parents=True)
    for name in FOLDERS:
        p = save_dir / name
        if p.exists():
            if not (p / MARKER).exists():
                raise FileExistsError(
                    f"'{p}' already exists and was not created by MyeliMetric. "
                    "Choose an empty folder or a previous MyeliMetric output folder.")
            shutil.rmtree(p)
            log(f"Removed previous MyeliMetric results in {p.name}/ so old and new results cannot mix.")
    for name in FOLDERS:
        (save_dir / name).mkdir()
        (save_dir / name / MARKER).write_text(f"{APP_NAME} {__version__}\n")
    return save_dir


def per_subset_stats(d: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (animal, k), grp in d[d["InSubset"]].groupby(["Animal", "Subset"], sort=False):
        x = grp["GRatio"].to_numpy(float)
        if len(x) < 3:
            continue
        m, sd = x.mean(), x.std(ddof=1)
        lo, hi = st.t.interval(0.95, len(x) - 1, loc=m, scale=sd / np.sqrt(len(x))) if sd > 0 else (m, m)
        w, p = st.shapiro(x)
        rows.append({"EXP_name": _sheet_name(animal, int(k)), "Animal": animal, "Subset": int(k),
                     "N": len(x), "Median": float(np.median(x)), "Mean": m, "Standard Deviation": sd,
                     "95% CI Lower": lo, "95% CI Upper": hi, "Shapiro-Stat": float(w),
                     "Shapiro-p-value": float(p), "Normality": "Yes" if p > 0.05 else "No"})
    out = pd.DataFrame(rows)
    if not out.empty:
        order = {a: i for i, a in enumerate(dict.fromkeys(d["Animal"]))}
        out = out.sort_values(["Animal", "Subset"], key=lambda s: s.map(order) if s.name == "Animal" else s)
    return out.reset_index(drop=True)


V2_STATS_COLUMNS = ["EXP_name", "Median", "Mean", "Standard Deviation", "95% CI Lower", "95% CI Upper",
                    "Shapiro-Stat", "Shapiro-p-value", "Normality"]


def wide_view(d: pd.DataFrame) -> pd.DataFrame:
    """V2 Cleaned workbook layout: FiberDiameter_ID, ID_Ax, ID_My for every animal (with its
    Slide-ID column when given), spacer columns, then G-Ratio_ID columns. Rows keep their
    original positions; excluded measurements are left blank."""
    animals = list(dict.fromkeys(d["Animal"]))
    nrows = int(d["SourceRow"].max()) - 1 if len(d) else 0
    cols, gcols = {}, {}
    for a in animals:
        g = d[d["Animal"] == a]
        idx = (g["SourceRow"].to_numpy() - 2).astype(int)
        def place(values):
            out = np.full(nrows, np.nan, dtype=object if values.dtype == object else float)
            out[idx] = values
            return out
        ok = g["Included"].to_numpy()
        cols[f"FiberDiameter_{a}"] = place(np.where(ok, g["FiberDiameter"], np.nan))
        cols[f"{a}_Ax"] = place(np.where(ok, g["Ax"], np.nan))
        cols[f"{a}_My"] = place(np.where(ok, g["My"], np.nan))
        if "Section" in g.columns:
            cols[f"Slide-ID_{a}"] = place(g["Section"].to_numpy(dtype=object))
        gcols[f"G-Ratio_{a}"] = place(np.where(ok, g["GRatio"], np.nan))
    for i in range(1, len(animals)):
        cols[f"  sp{i}"] = np.full(nrows, np.nan)
    cols.update(gcols)
    return pd.DataFrame(cols)


def ranges_table(ranges: pd.DataFrame, tag: str, label: str) -> pd.DataFrame:
    """V2 Ranges workbook: Subset, Min Fiber Diameter, Max Fiber Diameter."""
    lab = label.title()
    return pd.DataFrame({
        "Subset": [f"{tag}_Subset{k}" for k in ranges["Subset"]],
        f"Min {lab}": ranges["Min"].round(4), f"Max {lab}": ranges["Max"].round(4),
    })


def process_group(d, tag, folder: Path, settings, log: Logger, ranges=None, source=""):
    """Run the per-group pipeline. CTL defines ranges when ``ranges`` is None."""
    start = len(log.lines)
    log(f"=== {tag} pipeline started ===")
    if source:
        log(f"Input: {source}")
    animals = list(dict.fromkeys(d["Animal"]))
    log(f"Detected {len(animals)} sample(s): {', '.join(animals)}")
    d = proc.clean_and_compute(d, settings)
    removed = int((~d["Included"]).sum())
    log(f"Cleanup applied (axon < {settings.min_axon:g} um or myelin < {settings.min_myelin:g} um excluded; "
        f"incomplete pairs excluded). Measurements read: {len(d)}, kept: {int(d['Included'].sum())}, removed: {removed}.")
    log("Fiber diameter computed (axon + myelin). G-ratio computed (axon / fiber).")
    for sub in ("Cleaned", "Subsets", "Stats", "Histograms", "ScatterPlots", "Figures"):
        (folder / sub).mkdir(exist_ok=True)
    meas = d.drop(columns=["Included"]).copy()
    _xlsx(folder / "Cleaned" / f"Cleaned_{tag}.xlsx", {"Sheet1": wide_view(d)})
    log(f"Cleaned data saved: {folder / 'Cleaned' / f'Cleaned_{tag}.xlsx'}")
    for a in animals:
        fig.scatter_plot(d, a, folder / "ScatterPlots" / f"{a}_scatter_plot.png")
    log(f"Scatter plots saved to {folder / 'ScatterPlots'}")
    label = proc.BIN_LABEL[settings.bin_variable]
    if ranges is None:
        ranges = proc.reference_ranges(d, settings)
        how = "ALL pooled controls" if settings.reference == "pooled" else f"first control animal ({animals[0]})"
        log(f"{label} bin ranges computed from {how}:")
        for r in ranges.itertuples():
            log(f"    {tag}_Subset{r.Subset}: {r.LowerEdge:.2f} - {r.UpperEdge:.2f} um")
        _xlsx(folder / "Subsets" / f"Ranges_{tag}.xlsx", {f"{tag}_Ranges": ranges_table(ranges, tag, label)})
    else:
        log("Reusing control bin ranges.")
    d = proc.assign_subsets(d, ranges, settings)
    outside = int((d["Included"] & ~d["InSubset"]).sum())
    if outside:
        log(f"NOTE: {outside} included fiber(s) lie outside the control bin range and are not in any subset "
            "(listed in Summary/Exclusion_Audit.xlsx).")
    sheets = {}
    for a in animals:
        for k in ranges["Subset"]:
            s = d[(d["Animal"] == a) & (d["Subset"] == k)]
            sheets[_sheet_name(a, int(k))] = pd.DataFrame({
                f"FiberDiameter_{a}": s["FiberDiameter"].to_numpy(), f"{a}_Ax": s["Ax"].to_numpy(),
                f"{a}_My": s["My"].to_numpy(), f"G-Ratio_{a}": s["GRatio"].to_numpy()})
    _xlsx(folder / "Subsets" / f"Subsets_{tag}.xlsx", sheets)
    log(f"Subsets saved: {folder / 'Subsets' / f'Subsets_{tag}.xlsx'}")
    stats_tbl = per_subset_stats(d)
    _xlsx(folder / "Stats" / f"Stats_{tag}.xlsx", {"Statistical_analysis": stats_tbl[V2_STATS_COLUMNS]
                                                     if len(stats_tbl) else stats_tbl})
    log(f"Per-subset statistics saved: {folder / 'Stats' / f'Stats_{tag}.xlsx'}")
    if settings.make_histograms:
        for a in animals:
            for k in ranges["Subset"]:
                vals = d.loc[(d["Animal"] == a) & (d["Subset"] == k), "GRatio"]
                fig.histogram(vals, _sheet_name(a, int(k)), folder / "Histograms" / f"{_sheet_name(a, int(k))}.png")
        log(f"G-ratio histograms saved to {folder / 'Histograms'}")
    fig.normality_overview(stats_tbl, "", folder / "Figures" / f"Normality_Overview_{tag}.png", tag=tag)
    log(f"Normality overview figure saved: {folder / 'Figures' / f'Normality_Overview_{tag}.png'}")
    log(f"=== {tag} pipeline finished ===")
    log.write(folder / f"run_log_{tag}.txt", start)
    return d, ranges, stats_tbl


def run_statistics(all_d, groups, settings, out: Path, log: Logger):
    out.mkdir(exist_ok=True)
    log("=== Animal-level statistics ===")
    cells = ms.subset_cells(all_d, settings.cell_statistic)
    if settings.cell_statistic == "median":
        animals = ms.animal_values_from_cells(cells, all_d)
        log("Cell summary: MEDIAN g-ratio of each animal in each bin (as in the Prism workflow); "
            "animal value for the group test = mean of its bin medians.")
    else:
        animals = ms.animal_means(all_d)
        log("Cell summary: MEAN g-ratio of each animal in each bin.")
    fig.animal_plot(animals, groups, out / "Animal_Level_Plot.png",
                    ylabel="Mean of bin medians per animal" if settings.cell_statistic == "median"
                    else "Mean g-ratio per animal")
    n_by = animals.groupby("Group")["Animal"].nunique().to_dict()
    log("Biological n (animals): " + ", ".join(f"{g} = {n_by.get(g, 0)}" for g in groups)
        + f"; axons (technical subsamples): {int(animals['NAxons'].sum())}.")
    sheets = {"README": README_SHEET, "Animal_Means": animals}
    if not settings.animals_confirmed:
        msg = ("Inferential statistics were NOT run because you did not confirm that each sample ID is a "
               "different, independent animal. Descriptive animal means are saved. Tick the confirmation "
               "box in the Run panel and analyze again to obtain p-values.")
        (out / "INFERENCE_NOT_RUN.txt").write_text(msg + "\n", encoding="utf-8")
        _xlsx(out / "Statistics_Report.xlsx", sheets)
        log(msg)
        return {"inference": False}
    results, diag = {}, []
    try:
        results["animal"] = ms.animal_level_test(animals, groups)
        sheets["Animal_Level_Test"] = results["animal"]
        r = results["animal"].iloc[0]
        log(f"Animal-level t test: t({r.df_Student:.0f}) = {r.t_Student:.3f}, p = {r.p_Student:.4g}; "
            f"permutation p = {r.p_permutation:.4g} ({r.Permutation_type}, smallest possible "
            f"{r.Smallest_possible_permutation_p:.3g}); Hedges g = {r.Hedges_g:.2f}.")
    except ms.DesignError as e:
        diag.append(f"Animal-level test not run: {e}")
    sheets["Animal_Subset_Cells"] = cells
    try:
        results["anova"], meta = ms.split_plot_anova(cells, groups)
        sheets["Group_x_Subset_ANOVA"] = results["anova"]
        log(f"Split-plot ANOVA (Group x Subset) on animal-by-subset {settings.cell_statistic}s: {meta['n_animals']} animals, "
            f"{meta['n_subsets']} bins, GG epsilon = {meta['gg_epsilon']:.3f}.")
    except ms.DesignError as e:
        diag.append(f"Group x Subset ANOVA not run: {e}")
    try:
        results["caliber"], info, notes = ms.caliber_model(all_d, groups)
        results["caliber_info"] = info
        sheets["Caliber_Mixed_Model"] = results["caliber"]
        diag += [f"Caliber model ({info['structure']}; optimizer {info['optimizer']})"] + notes
        fig.caliber_plot(all_d[all_d["Included"]], info, groups, out / "Caliber_Model_Plot.png")
        log(f"Caliber mixed model fitted ({info['structure']}).")
    except ms.DesignError as e:
        diag.append(f"Caliber mixed model not run: {e}")
    try:
        results["mixed"], notes = ms.group_mixed_model(all_d, groups)
        sheets["Animal_Mixed_Model"] = results["mixed"]
        diag += [f"Animal mixed model ({results['mixed'].Structure.iloc[0]})"] + notes
        log(f"Animal mixed model fitted ({results['mixed'].Structure.iloc[0]}).")
    except ms.DesignError as e:
        diag.append(f"Animal mixed model not run: {e}")
    for line in diag:
        if "not run" in line:
            log(line)
    sheets["Diagnostics"] = pd.DataFrame({"Message": diag or ["No problems reported."]})
    _xlsx(out / "Statistics_Report.xlsx", sheets)
    text = results_text(results, animals, groups, settings)
    (out / "Results_Summary.txt").write_text(text, encoding="utf-8")
    log(f"Statistics saved: {out / 'Statistics_Report.xlsx'} and Results_Summary.txt")
    results["inference"] = True
    return results


def analyze(ctl_path, exp_path, save_dir, settings: proc.Settings, callback=None):
    """Full standard workflow. Returns a dict describing the run."""
    settings.validate()
    log = Logger(callback)
    save_dir = prepare_output(Path(save_dir), log)
    log(f"{APP_NAME} {__version__}. Settings: {json.dumps(settings.to_dict())}")
    (save_dir / "settings.json").write_text(json.dumps(
        {"app": APP_NAME, "version": __version__, "settings": settings.to_dict(),
         "control_file": str(ctl_path), "experimental_file": str(exp_path or ""),
         "run": f"{_dt.datetime.now():%Y-%m-%d %H:%M:%S}"}, indent=2))
    ctl, layout = io.load_group_file(ctl_path, "CTL")
    if layout == "long":
        if exp_path:
            raise io.InputError("A long-format table already contains both groups; leave Step 2 empty.")
        groups_in = list(dict.fromkeys(ctl["Group"]))
        groups = ms.order_groups(groups_in) if len(groups_in) == 2 else groups_in
        if len(groups) > 2:
            raise io.InputError(f"Long-format table has {len(groups)} groups; MyeliMetric compares two.")
        log(f"Long-format table detected with group(s): {', '.join(groups)}"
            + ("; Section IDs present." if "Section" in ctl.columns else "."))
        parts = [ctl[ctl["Group"] == g].reset_index(drop=True) for g in groups]
        sources = [str(ctl_path)] * len(parts)
    else:
        parts, groups, sources = [ctl], ["CTL"], [str(ctl_path)]
        if exp_path:
            exp, layout2 = io.load_group_file(exp_path, "EXP")
            if layout2 == "long":
                raise io.InputError("Step 2 received a long-format table. Load it in Step 1 instead.")
            parts.append(exp)
            groups.append("EXP")
            sources.append(str(exp_path))
    has_sec = ["Section" in d.columns for d in parts]
    if any(has_sec) and not all(has_sec):
        raise io.InputError("Section/slide IDs are present in one group's file but not the other. "
                            "Provide them for both groups, or for neither.")
    log("Section/slide IDs found: random effects for animal and section within animal." if any(has_sec) else
        "No section/slide IDs: mixed models use animal IDs alone (the animal remains the unit of inference).")
    done, ranges, stats_tables = [], None, []
    for i, (part, g, src) in enumerate(zip(parts, groups, sources)):
        folder = save_dir / ("Control" if i == 0 else "Experimental")
        d, r, s = process_group(part, g, folder, settings, log, ranges=ranges, source=src)
        ranges = ranges if ranges is not None else r
        done.append(d)
        stats_tables.append(s.assign(Group=g))
    all_d = pd.concat(done, ignore_index=True)
    summary = save_dir / "Summary"
    audit = proc.exclusion_audit(all_d)
    excluded_rows = all_d[all_d["ExclusionReason"] != ""].drop(columns=["Included", "InSubset"])
    _xlsx(summary / "Exclusion_Audit.xlsx", {"Counts_by_animal": audit, "Excluded_measurements": excluded_rows})
    log(f"Exclusion audit saved: {summary / 'Exclusion_Audit.xlsx'}")
    per = pd.concat(stats_tables, ignore_index=True)
    per = per[["Group"] + [c for c in per.columns if c != "Group"]]
    cells = ms.subset_cells(all_d)
    grand = (cells.groupby("Group", sort=False)["Mean"].agg(["size", "mean", "std"]).reset_index()
             .rename(columns={"size": "Subsets Used", "mean": "Grand Mean G-Ratio", "std": "SD of Subset Means"}))
    label = proc.BIN_LABEL[settings.bin_variable]
    result = {"save_dir": str(save_dir), "groups": groups, "n_axons": int(all_d["Included"].sum())}
    if len(groups) == 2:
        fig.summary_plot(cells, ranges, groups, label, summary / "Summary_CTL_vs_EXP.png")
        _xlsx(summary / "Summary_Report.xlsx", {
            "Per_Subset": per[["Group"] + V2_STATS_COLUMNS], "Grand_Means": grand.round(4),
        })
        log("Summary report and CTL vs EXP figure saved.")
        stats_res = run_statistics(all_d, groups, settings, summary / "Statistics", log)
        scells = ms.subset_cells(all_d, settings.cell_statistic)
        if "anova" in stats_res:
            write_nested_anova_workbook(summary / "Statistics" / "Nested_ANOVA_Results.xlsx", stats_res, scells,
                                        groups, ranges, label)
            log("Nested ANOVA results saved: " + str(summary / "Statistics" / "Nested_ANOVA_Results.xlsx"))
        anova_text = None
        if "anova" in stats_res:
            t = stats_res["anova"].set_index("Effect")
            def fmt(pv):
                return "p < 0.001" if pv < 0.001 else f"p = {pv:.3f}"
            g_, s_, i_ = t.loc["Group"], t.loc["Subset"], t.loc["Group x Subset"]
            anova_text = ("Nested split-plot ANOVA (n = animals)\n"
                          f"Group:         F({g_.df_num:.0f},{g_.df_den:.0f}) = {g_.F:.1f}, {fmt(g_.p_uncorrected)}\n"
                          f"Bin:           F({s_.df_num:.0f},{s_.df_den:.0f}) = {s_.F:.2f}, GG {fmt(s_.p_GG)}\n"
                          f"Group x Bin:   F({i_.df_num:.0f},{i_.df_den:.0f}) = {i_.F:.2f}, GG {fmt(i_.p_GG)}")
            if "mixed" in stats_res:
                m = stats_res["mixed"].iloc[0]
                lvl = "animal + section" if m.Nested else "animal"
                anova_text += (f"\nMixed model ({lvl}): diff {m.Estimate:+.3f},\n"
                               f"   t({m.df}) = {m.t:.1f}, {fmt(m.p)}")
        elif not stats_res.get("inference"):
            anova_text = "Statistics not run:\nanimals not confirmed"
        fig.animal_subset_plot(scells, ranges, groups, label, summary / "Final_Result.png",
                               anova_text)
        log("Main result figure saved: " + str(summary / "Final_Result.png"))
        result["statistics"] = stats_res
        p_text = None
        if "anova" in stats_res:
            r = stats_res["anova"].set_index("Effect").loc["Group"]
            pv = r.p_uncorrected
            p_text = (f"Group: F({r.df_num:.0f}, {r.df_den:.0f}) = {r.F:.1f}, "
                      + ("p < 0.001" if pv < 0.001 else f"p = {pv:.3f}") + " (animal n)")
        elif not stats_res.get("inference"):
            p_text = "p-values not run (animals not confirmed)"
        if stats_res.get("inference"):
            fig.grand_mean_plot(scells, groups, summary / "Statistics" / "Grand_Mean_GRatio.png", p_text)
            log("Grand mean g-ratio figure saved: " + str(summary / "Statistics" / "Grand_Mean_GRatio.png"))
    else:
        _xlsx(summary / "Summary_Report.xlsx", {"Per_Subset": per[["Group"] + V2_STATS_COLUMNS],
                                                "Grand_Means": grand.round(4)})
        log("Control-only run: CTL vs EXP comparison and statistics skipped.")
    log("Analysis complete.")
    log.write(save_dir / "MyeliMetric_run_log.txt")
    result["log"] = list(log.lines)
    return result


# ----------------------------------------------------------------- advanced stages
def _load_parts(ctl_path, exp_path):
    ctl, layout = io.load_group_file(ctl_path, "CTL")
    if layout == "long":
        groups = list(dict.fromkeys(ctl["Group"]))
        groups = ms.order_groups(groups) if len(groups) == 2 else groups
        return [(ctl[ctl["Group"] == g].reset_index(drop=True), g) for g in groups]
    parts = [(ctl, "CTL")]
    if exp_path:
        parts.append((io.load_group_file(exp_path, "EXP")[0], "EXP"))
    return parts


def clean_only(ctl_path, exp_path, save_dir, settings, callback=None):
    """Stage 1 only: exclusion, fiber diameter and g-ratio, with the exclusion audit."""
    settings.validate()
    log = Logger(callback)
    out = Path(save_dir) / "Cleaned_only"
    out.mkdir(parents=True, exist_ok=True)
    frames = []
    for part, g in _load_parts(ctl_path, exp_path):
        d = proc.clean_and_compute(part, settings)
        d["InSubset"] = d["Included"]
        _xlsx(out / f"Cleaned_{g}.xlsx", {"Sheet1": wide_view(d), "All_measurements": d.drop(columns=["Included", "InSubset"])})
        log(f"{g}: {len(d)} measurements read, {int(d['Included'].sum())} kept. Saved Cleaned_{g}.xlsx")
        frames.append(d)
    _xlsx(out / "Exclusion_Audit.xlsx", {"Counts_by_animal": proc.exclusion_audit(pd.concat(frames))})
    log(f"Exclusion audit saved in {out}")
    return str(out)


def ranges_only(ctl_path, save_dir, settings, callback=None):
    """Stage 2 only: control-derived bin ranges."""
    settings.validate()
    log = Logger(callback)
    part, g = _load_parts(ctl_path, None)[0]
    d = proc.clean_and_compute(part, settings)
    r = proc.reference_ranges(d, settings)
    out = Path(save_dir) / "Ranges_only"
    out.mkdir(parents=True, exist_ok=True)
    _xlsx(out / f"Ranges_{g}.xlsx", {f"{g}_Ranges": ranges_table(r, g, proc.BIN_LABEL[settings.bin_variable])})
    for row in r.itertuples():
        log(f"    {g}_Subset{row.Subset}: {row.LowerEdge:.2f} - {row.UpperEdge:.2f} um ({row.ReferenceCount} control fibers)")
    log(f"Ranges saved: {out / f'Ranges_{g}.xlsx'}")
    return str(out)


def write_long_template(path):
    pd.DataFrame({
        "Group": ["CTL", "CTL", "CTL", "EXP", "EXP", "EXP"],
        "Animal": ["M1", "M1", "M1", "M7", "M7", "M7"],
        "Section": ["S1", "S1", "S2", "S1", "S2", "S2"],
        "Ax": [0.82, 0.65, 0.71, 0.77, 0.58, 0.90],
        "My": [0.28, 0.24, 0.26, 0.19, 0.15, 0.22],
    }).to_csv(path, index=False)
    return str(path)
