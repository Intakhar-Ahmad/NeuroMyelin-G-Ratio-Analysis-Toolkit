"""Inferential statistics with the animal as the experimental unit.

Hierarchy: axons are nested in (sections, when given, nested in) animals, and
animals are nested in groups. Axons and sections are technical subsamples; the
number of animals is the biological n. Every test here respects that:

1. animal_level_test   two-group comparison of per-animal mean g-ratios
                       (Student t / one-way ANOVA, Welch, exact permutation),
                       with mean difference, 95% CI and Hedges' g.
2. split_plot_anova    Group (between animals) x caliber Subset (within animals)
                       on animal-by-subset means, Greenhouse-Geisser and
                       Huynh-Feldt corrected, with partial and generalized eta^2.
3. caliber_model       per-axon linear mixed model, g-ratio ~ Group * axon
                       diameter with animal random intercepts and slopes
                       (plus a section variance component when sections exist).
                       Uses no bins, so it avoids the coupling between fiber
                       diameter bins and myelin thickness.
4. group_mixed_model   per-axon model g-ratio ~ Group with an animal random
                       intercept; adds a section-within-animal intercept when
                       section IDs are provided (optional).

Mixed-model fixed effects are tested with t statistics on N_animals - 2 degrees
of freedom (between-animal containment df) rather than large-sample z tests,
which are anticonservative with few animals.
"""
from __future__ import annotations

import itertools
import warnings
from math import comb

import numpy as np
import pandas as pd
from scipy import stats as st


class DesignError(ValueError):
    """The data cannot support the requested analysis."""


def order_groups(groups) -> list[str]:
    groups = list(dict.fromkeys(str(g) for g in groups))
    if len(groups) != 2:
        raise DesignError(f"Exactly two groups are required; found {len(groups)}: {groups}")
    upper = [g.upper() for g in groups]
    if "CTL" in upper:
        ref = groups[upper.index("CTL")]
        return [ref] + [g for g in groups if g != ref]
    return sorted(groups)


def _subject(d):
    return d["Group"].astype(str) + "::" + d["Animal"].astype(str)


# --------------------------------------------------------------------------- 1
def animal_means(d: pd.DataFrame, column="Included") -> pd.DataFrame:
    """One mean g-ratio per animal. Sections, if present, get equal weight."""
    v = d[d[column]].copy()
    ids = ["Group", "Animal"]
    if "Section" in v.columns:
        sec = v.groupby(ids + ["Section"], sort=False).agg(m=("GRatio", "mean"), n=("GRatio", "size")).reset_index()
        out = sec.groupby(ids, sort=False).agg(MeanGRatio=("m", "mean"), NSections=("Section", "nunique"),
                                               NAxons=("n", "sum")).reset_index()
    else:
        out = v.groupby(ids, sort=False).agg(MeanGRatio=("GRatio", "mean"), NAxons=("GRatio", "size")).reset_index()
        out["NSections"] = np.nan
    ax = v.groupby(ids, sort=False)["AxonDiameter"].mean().rename("MeanAxonDiameter").reset_index()
    return out.merge(ax, on=ids)


def permutation_p(x, y, max_exact=200_000, n_random=100_000, seed=20251):
    """Two-sided permutation p for the difference in means of animal values."""
    allv = np.concatenate([x, y]).astype(float)
    n, k = len(allv), len(x)
    obs = abs(np.mean(y) - np.mean(x))
    total = comb(n, k)
    tot_sum = allv.sum()
    if total <= max_exact:
        diffs = []
        for idx in itertools.combinations(range(n), k):
            sx = allv[list(idx)].sum()
            diffs.append(abs((tot_sum - sx) / (n - k) - sx / k))
        diffs = np.asarray(diffs)
        p_min = float(np.mean(diffs >= diffs.max() - 1e-12))
        return float(np.mean(diffs >= obs - 1e-12)), int(total), "exact", p_min
    rng = np.random.default_rng(seed)
    hits = 0
    for _ in range(n_random):
        p = rng.permutation(allv)
        hits += abs(p[k:].mean() - p[:k].mean()) >= obs - 1e-12
    return float((hits + 1) / (n_random + 1)), n_random, "Monte Carlo", 1.0 / (n_random + 1)


def animal_level_test(animals: pd.DataFrame, groups) -> pd.DataFrame:
    a, b = groups
    x = animals.loc[animals["Group"] == a, "MeanGRatio"].to_numpy(float)
    y = animals.loc[animals["Group"] == b, "MeanGRatio"].to_numpy(float)
    if min(len(x), len(y)) < 2:
        raise DesignError("At least 2 animals per group are needed for animal-level inference.")
    vx, vy = x.var(ddof=1), y.var(ddof=1)
    if vx == 0 and vy == 0:
        raise DesignError("No variation between animals; inference is not estimable.")
    nx, ny = len(x), len(y)
    diff = y.mean() - x.mean()
    # Student t (identical to one-way ANOVA with two groups: F = t^2)
    t_s = st.ttest_ind(y, x, equal_var=True)
    sp = np.sqrt(((nx - 1) * vx + (ny - 1) * vy) / (nx + ny - 2))
    se_s = sp * np.sqrt(1 / nx + 1 / ny)
    tcrit_s = st.t.ppf(0.975, nx + ny - 2)
    # Welch
    t_w = st.ttest_ind(y, x, equal_var=False)
    se_w = np.sqrt(vx / nx + vy / ny)
    df_w = se_w ** 4 / ((vx / nx) ** 2 / (nx - 1) + (vy / ny) ** 2 / (ny - 1))
    tcrit_w = st.t.ppf(0.975, df_w)
    # Hedges' g (bias-corrected standardized difference)
    d_coh = diff / sp if sp > 0 else np.nan
    J = 1 - 3 / (4 * (nx + ny) - 9)
    g = d_coh * J
    se_g = np.sqrt((nx + ny) / (nx * ny) + g ** 2 / (2 * (nx + ny)))
    p_perm, n_perm, kind, p_min = permutation_p(x, y)
    return pd.DataFrame([{
        "ReferenceGroup": a, "ComparisonGroup": b, "N_animals_ref": nx, "N_animals_comp": ny,
        "N_axons_ref": int(animals.loc[animals.Group == a, "NAxons"].sum()),
        "N_axons_comp": int(animals.loc[animals.Group == b, "NAxons"].sum()),
        "Mean_ref": x.mean(), "SD_ref": np.sqrt(vx), "Mean_comp": y.mean(), "SD_comp": np.sqrt(vy),
        "Difference_comp_minus_ref": diff,
        "CI95_low_Student": diff - tcrit_s * se_s, "CI95_high_Student": diff + tcrit_s * se_s,
        "t_Student": float(t_s.statistic), "df_Student": nx + ny - 2, "p_Student": float(t_s.pvalue),
        "F_ANOVA": float(t_s.statistic) ** 2,
        "t_Welch": float(t_w.statistic), "df_Welch": float(df_w), "p_Welch": float(t_w.pvalue),
        "CI95_low_Welch": diff - tcrit_w * se_w, "CI95_high_Welch": diff + tcrit_w * se_w,
        "Hedges_g": g, "Hedges_g_CI95_low": g - 1.96 * se_g, "Hedges_g_CI95_high": g + 1.96 * se_g,
        "p_permutation": p_perm, "Permutation_type": kind, "N_permutations": n_perm,
        "Smallest_possible_permutation_p": p_min,
    }])


# --------------------------------------------------------------------------- 2
def subset_cells(d: pd.DataFrame, statistic: str = "mean") -> pd.DataFrame:
    """One row per animal x bin. ``Value`` is the cell summary used by the nested ANOVA:
    the mean (default) or the median of that animal's fibers in that bin."""
    v = d[d["InSubset"]]
    cells = (v.groupby(["Group", "Animal", "Subset"], sort=False)["GRatio"]
             .agg(Mean="mean", SD="std", Median="median", Q1=lambda x: x.quantile(0.25),
                  Q3=lambda x: x.quantile(0.75), N="size").reset_index())
    cells["Value"] = cells["Median"] if statistic == "median" else cells["Mean"]
    cells["Statistic"] = statistic
    cells["Subset"] = cells["Subset"].astype(int)
    order = {key: i for i, key in enumerate(dict.fromkeys(zip(v["Group"], v["Animal"])))}
    cells["_o"] = [order[(g, a)] for g, a in zip(cells["Group"], cells["Animal"])]
    return cells.sort_values(["_o", "Subset"]).drop(columns="_o").reset_index(drop=True)


def _hf_epsilon(gg, n_subjects, n_groups, k):
    p = k - 1
    num = (n_subjects - n_groups + 1) * p * gg - 2
    den = p * (n_subjects - n_groups - p * gg)
    return float(min(1.0, num / den)) if den > 0 else 1.0


def split_plot_anova(cells: pd.DataFrame, groups) -> tuple[pd.DataFrame, dict]:
    subsets = sorted(cells["Subset"].astype(int).unique())
    k = len(subsets)
    if k < 2:
        raise DesignError("The Group x Subset analysis needs at least 2 caliber bins.")
    arrays, missing = [], []
    for g in groups:
        col = "Value" if "Value" in cells.columns else "Mean"
        piv = (cells[cells["Group"] == g].pivot(index="Animal", columns="Subset", values=col)
               .reindex(columns=subsets))
        if len(piv) < 2:
            raise DesignError(f"Group {g} has fewer than 2 animals.")
        for animal, row in piv.iterrows():
            for s in row.index[row.isna()]:
                missing.append(f"{animal} (bin {s})")
        arrays.append(piv.to_numpy(float))
    if missing:
        raise DesignError("Every animal needs at least one fiber in every bin. Empty cells: "
                          + ", ".join(missing) + ". Use fewer bins, or rely on the caliber mixed model.")
    allx = np.vstack(arrays)
    n, a = len(allx), len(groups)
    grand = allx.mean()
    gm = [x.mean() for x in arrays]
    sm = allx.mean(axis=0)
    gsm = [x.mean(axis=0) for x in arrays]
    ss_group = sum(len(x) * k * (m - grand) ** 2 for x, m in zip(arrays, gm))
    ss_subj = sum(k * np.sum((x.mean(axis=1) - m) ** 2) for x, m in zip(arrays, gm))
    ss_subset = n * np.sum((sm - grand) ** 2)
    ss_inter = sum(len(x) * np.sum((g_ - m - sm + grand) ** 2) for x, m, g_ in zip(arrays, gm, gsm))
    ss_err = sum(np.sum((x - x.mean(axis=1, keepdims=True) - g_[None, :] + x.mean()) ** 2)
                 for x, g_ in zip(arrays, gsm))
    df_g, df_s, df_sub, df_i, df_e = a - 1, n - a, k - 1, (a - 1) * (k - 1), (n - a) * (k - 1)
    if ss_subj <= 0 or ss_err <= 0:
        raise DesignError("Zero between-animal or residual variance; F tests are not estimable.")
    pooled = sum((x - x.mean(axis=0)).T @ (x - x.mean(axis=0)) for x in arrays) / (n - a)
    C = np.eye(k) - np.ones((k, k)) / k
    S = C @ pooled @ C
    gg = float(np.clip(np.trace(S) ** 2 / ((k - 1) * np.trace(S @ S)), 1 / (k - 1), 1)) if k > 2 else 1.0
    hf = _hf_epsilon(gg, n, a, k) if k > 2 else 1.0
    ms_b, ms_w = ss_subj / df_s, ss_err / df_e
    rows = []
    for name, ss, df1, ms_e, df2, within in [
        ("Group", ss_group, df_g, ms_b, df_s, False),
        ("Subset", ss_subset, df_sub, ms_w, df_e, True),
        ("Group x Subset", ss_inter, df_i, ms_w, df_e, True),
    ]:
        F = (ss / df1) / ms_e
        rows.append({
            "Effect": name, "SS": ss, "df_num": df1, "df_den": df2, "F": F,
            "p_uncorrected": st.f.sf(F, df1, df2),
            "GG_epsilon": gg if within else np.nan,
            "p_GG": st.f.sf(F, df1 * gg, df2 * gg) if within else st.f.sf(F, df1, df2),
            "HF_epsilon": hf if within else np.nan,
            "p_HF": st.f.sf(F, df1 * hf, df2 * hf) if within else st.f.sf(F, df1, df2),
            "partial_eta2": ss / (ss + (ss_err if within else ss_subj)),
            "generalized_eta2": ss / (ss + ss_subj + ss_err),
        })
    return pd.DataFrame(rows), {"n_animals": n, "n_subsets": k, "gg_epsilon": gg, "hf_epsilon": hf}


# --------------------------------------------------------------------------- 3/4
def _fit_mixed(formula, data, groups, re_formula, vc):
    from statsmodels.formula.api import mixedlm
    notes, boundary = [], None
    model = mixedlm(formula, data, groups=groups, re_formula=re_formula, vc_formula=vc)
    for method in ("lbfgs", "bfgs", "powell", "nm"):
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                fit = model.fit(reml=True, method=method, maxiter=3000, disp=False)
            notes += [f"{method}: {w.message}" for w in caught]
            finite = np.all(np.isfinite(fit.bse_fe))
            if fit.converged and finite:
                return fit, method, notes
            if finite and boundary is None:
                boundary = (fit, method)
            notes.append(f"{method}: not converged")
        except (ValueError, np.linalg.LinAlgError) as exc:
            notes.append(f"{method}: {type(exc).__name__}: {exc}")
    if boundary is not None and re_formula == "1":
        # Typical cause: a variance component estimated at zero (boundary). Fixed effects and their
        # standard errors remain usable; the note is reported in Diagnostics.
        notes.append(f"Using {boundary[1]} fit with a variance component on the boundary (estimated ~0).")
        return boundary[0], boundary[1] + " (boundary)", notes
    return None, None, notes


def _t_rows(fit, terms, df):
    out = []
    for label, term in terms:
        est, se = float(fit.params[term]), float(fit.bse[term])
        t = est / se
        tc = st.t.ppf(0.975, df)
        out.append({"Term": label, "Estimate": est, "SE": se, "t": t, "df": df,
                    "p": 2 * st.t.sf(abs(t), df), "CI95_low": est - tc * se, "CI95_high": est + tc * se})
    return out


def _prepare(d, groups):
    v = d[d["Included"]].copy()
    v["Subject"] = _subject(v)
    v["G"] = pd.Categorical(v["Group"].astype(str), categories=list(groups))
    v["Y"] = v["GRatio"] * 100.0          # percent scale for numerical stability; reported back on g scale
    counts = v.groupby("Group")["Subject"].nunique()
    if (counts.reindex(groups).fillna(0) < 3).any():
        raise DesignError("Mixed models need at least 3 animals per group.")
    return v


def caliber_model(d: pd.DataFrame, groups) -> tuple[pd.DataFrame, dict, list[str]]:
    v = _prepare(d, groups)
    center = float(v["AxonDiameter"].mean())
    v["AxC"] = v["AxonDiameter"] - center
    has_sec = "Section" in v.columns
    vc = {"Section": "0 + C(Section)"} if has_sec else None
    fit, method, notes = _fit_mixed("Y ~ C(G) * AxC", v, v["Subject"], "1 + AxC", vc)
    structure = "random intercept and axon-diameter slope per animal"
    if fit is None:
        notes.append("Random-slope model failed; falling back to random intercept only.")
        fit, method, notes2 = _fit_mixed("Y ~ C(G) * AxC", v, v["Subject"], "1", vc)
        notes += notes2
        structure = "random intercept per animal"
    if fit is None:
        raise DesignError("Caliber mixed model did not converge. " + "; ".join(notes[-3:]))
    if has_sec:
        structure += " + section-within-animal variance component"
    b = groups[1]
    gterm, iterm = f"C(G)[T.{b}]", f"C(G)[T.{b}]:AxC"
    dfree = v["Subject"].nunique() - 2
    rows = _t_rows(fit, [
        (f"Group difference ({b} - {groups[0]}) at mean axon diameter {center:.3f} um", gterm),
        (f"Axon-diameter slope in {groups[0]} (per um)", "AxC"),
        (f"Slope difference ({b} - {groups[0]}) (Group x axon diameter)", iterm),
    ], dfree)
    res = pd.DataFrame(rows)
    for c in ("Estimate", "SE", "CI95_low", "CI95_high"):
        res[c] = res[c] / 100.0
    p = fit.params / 100.0
    lines = {groups[0]: (p["Intercept"], p["AxC"]),
             b: (p["Intercept"] + p[gterm], p["AxC"] + p[iterm])}
    info = {"center": center, "lines": lines, "structure": structure, "optimizer": method,
            "n_animals": int(v["Subject"].nunique()), "n_axons": int(len(v)), "df": dfree}
    return res, info, notes


def group_mixed_model(d: pd.DataFrame, groups) -> tuple[pd.DataFrame, list[str]]:
    """Per-axon g-ratio ~ Group with an animal random intercept.

    Section IDs are optional. When every animal has at least 2 sections, a
    section-within-animal variance component is added (nested model). Without
    them the model uses animal IDs alone; the animal remains the unit of inference
    either way (t test on N animals - 2 df).
    """
    v = _prepare(d, groups)
    notes = []
    nested = "Section" in v.columns
    if nested:
        v["SubSec"] = v["Subject"] + "::" + v["Section"].astype(str)
        if (v.groupby("Subject")["SubSec"].nunique() < 2).any():
            nested = False
            notes.append("Some animals have only 1 section, so section variance cannot be separated from "
                         "animal variance; fitted the animal-only model.")
    vc = {"Section": "0 + C(SubSec)"} if nested else None
    fit, method, n2 = _fit_mixed("Y ~ C(G)", v, v["Subject"], "1", vc)
    notes += n2
    if fit is None:
        raise DesignError("Animal mixed model did not converge. " + "; ".join(notes[-3:]))
    b = groups[1]
    dfree = v["Subject"].nunique() - 2
    row = {"Structure": ("animal random intercept + section-within-animal random intercept" if nested
                         else "animal random intercept (no section IDs used)")}
    row.update(_t_rows(fit, [(f"Group difference ({b} - {groups[0]})", f"C(G)[T.{b}]")], dfree)[0])
    for c in ("Estimate", "SE", "CI95_low", "CI95_high"):
        row[c] /= 100.0
    va = float(fit.cov_re.iloc[0, 0]) / 1e4
    vs = float(fit.vcomp[0]) / 1e4 if nested else 0.0
    ve = float(fit.scale) / 1e4
    tot = va + vs + ve
    row.update({"Var_animal": va, "Var_section_within_animal": vs if nested else np.nan,
                "Var_axon_residual": ve, "Share_animal": va / tot,
                "Share_section": vs / tot if nested else np.nan, "Share_axon": ve / tot,
                "ICC_animal": va / tot, "N_animals": int(v["Subject"].nunique()),
                "N_sections": int(v["SubSec"].nunique()) if nested else np.nan,
                "N_axons": int(len(v)), "Optimizer": method, "Nested": nested})
    return pd.DataFrame([row]), notes


def nested_model(d, groups):
    """Backward-compatible name: requires section IDs."""
    if "Section" not in d.columns:
        raise DesignError("No Section column; the nested animal/section model needs section IDs.")
    return group_mixed_model(d, groups)


def animal_values_from_cells(cells: pd.DataFrame, d: pd.DataFrame) -> pd.DataFrame:
    """Per-animal value for the median option: the mean of that animal's bin medians
    (the 'means of medians' used for the group t test in the Prism workflow)."""
    out = cells.groupby(["Group", "Animal"], sort=False)["Value"].mean().rename("MeanGRatio").reset_index()
    n = d[d["InSubset"]].groupby(["Group", "Animal"], sort=False).size().rename("NAxons").reset_index()
    ax = d[d["Included"]].groupby(["Group", "Animal"], sort=False)["AxonDiameter"].mean().rename("MeanAxonDiameter").reset_index()
    out = out.merge(n, on=["Group", "Animal"]).merge(ax, on=["Group", "Animal"])
    out["NSections"] = np.nan
    out["Summary"] = "mean of bin medians"
    return out
