# MyeliMetric-2.1

Standardized g-ratio analysis of axon-myelin integrity from post-segmented axon and myelin measurements, with statistics that use the animal as the experimental unit.

Version 2.1 keeps the complete V2 workflow (three-step run, one save location, adjustable bins and thresholds, pooled-control bin ranges, CSV input, run logs, exclusion audit, standalone Windows build) and adds animal-level inference.

## Quick start

1. Open `MyeliMetric-2.1.exe` (or run `RUN_FROM_SOURCE.bat`, or `python MyeliMetric2.1.py`).
2. Check the analysis settings. Defaults: 0.15 µm minimum axon, 0.03 µm minimum myelin, 6 bins, fiber-diameter bins from pooled controls.
3. Click **Choose save location**.
4. **Step 1**: load the control file. **Step 2**: load the experimental file.
5. Tick the box confirming that each sample ID is a different, independent animal (needed for p-values).
6. **Step 3: Analyze**.

## Input

**Wide layout (published format)**: one file per group, paired columns `CTL1_Ax, CTL1_My, CTL2_Ax, CTL2_My, ...` (or `EXP1_Ax, ...`). Excel or CSV. Spacer columns are ignored.

Optionally, put a `Slide-ID` column (or `Section`, `Slide`, `Field`, or `CTL1_Section`) directly after each animal's `_Ax`/`_My` pair, giving the slide or section each fiber was measured on. Section IDs are not mandatory. If they are given, they must be given for every animal in both groups. Examples: `example_Dataset/Example_CTL_3Animals_With_SlideIDs.xlsx` and `example_Dataset/Example_EXP_3Animals_With_SlideIDs.xlsx`.

**Long layout (new)**: one file with both groups, one row per fiber, columns `Group, Animal, Ax, My` and optionally `Section`. Load it in Step 1 and leave Step 2 empty. Use this layout when you measured several sections or fields per animal, so that section-level variation can be modelled. A template is in `example_Dataset/Template_long_format.csv`.

`_My` must be the full myelin contribution across the fiber (2 x radial thickness), because fiber diameter = Ax + My and g-ratio = Ax / (Ax + My).

## Output

| Folder | Files |
|:--|:--|
| `Control/` | Cleaned, Subsets (with `Ranges_CTL.xlsx`), Stats, Histograms, ScatterPlots, Figures, `run_log_CTL.txt` |
| `Experimental/` | Same files, using the control-derived bin ranges |
| `Summary/` | **`Final_Result.png`** (main result figure: every animal in every bin at the bin's upper edge in µm, with grand means), `Summary_Report.xlsx`, `Summary_CTL_vs_EXP.png`, `Exclusion_Audit.xlsx` |
| `Summary/Statistics/` | `Nested_ANOVA_Results.xlsx` (nested ANOVA and mixed-model results in one readable table, plus animal-by-bin means), `Statistics_Report.xlsx`, `Results_Summary.txt` (draft methods and results text), `Grand_Mean_GRatio.png`, `Animal_Level_Plot.png`, `Caliber_Model_Plot.png` |
| save location | `MyeliMetric_run_log.txt`, `settings.json` |

Running again into the same folder replaces the previous MyeliMetric results, so old and new files cannot mix. A folder that already holds `Control`, `Experimental` or `Summary` folders not made by MyeliMetric is refused.

## Statistics

Fibers from one animal are not independent, so the number of animals is the biological n. Fibers and sections are technical subsamples.

| Analysis | What it answers |
|:--|:--|
| Animal-level test | Do groups differ in mean g-ratio? One mean per animal (sections equally weighted). Student t (equal to one-way ANOVA), Welch t, exact permutation test, mean difference with 95% CI, Hedges' g. |
| Group x Subset split-plot ANOVA | Does the group difference depend on caliber bin? Animal-by-bin means (or medians, see below); Greenhouse-Geisser and Huynh-Feldt corrections; partial and generalized eta squared. Needs every animal to have fibers in every bin. |
| Caliber mixed model | Same question without bins: per-fiber g-ratio ~ Group x axon diameter, animal random intercept and slope. Avoids binning on fiber diameter, which contains the myelin being measured. |
| Animal mixed model | Group effect on per-fiber g-ratios with an animal random intercept, which accounts for the correlation among fibers from the same animal. When section IDs are provided, a section-within-animal random intercept is added (nested model). Reports how variance splits across animal, (section) and fiber. |

The pipeline supports animal-level mixed-effects analysis to account for correlations among axons measured from the same animal, with section-level nested modeling available when section identifiers are provided. Section IDs are not mandatory: without them the analysis uses animal IDs alone and keeps the animal as the unit of inference.

Mixed-model fixed effects are tested with t on N animals - 2 degrees of freedom. In simulations with 3 animals per group and no true effect, this gave a false-positive rate of 3%, compared with 11% for the large-sample z test.

**Means or medians.** By default each animal's fibers in a bin are summarized by their mean. In the advanced panel, "Nested ANOVA uses each animal's bin: Median (as in Prism)" summarizes them by the median instead, as in the GraphPad Prism mixed-effects workflow. With this option the split-plot ANOVA, `Final_Result.png` (median with interquartile range), `Nested_ANOVA_Results.xlsx` and the animal-level group test (mean of each animal's bin medians) all use medians. The V2 descriptive outputs and the mixed models are unchanged.

**Agreement with GraphPad Prism.** On the same per-mouse bin medians, the split-plot ANOVA gives the same results as Prism 10.4's two-way repeated-measures mixed-effects analysis (REML, sphericity not assumed): Treatment F(1, 4) = 0.3674, p = 0.5772; fiber diameter F = 0.9564, Greenhouse-Geisser epsilon 0.4441, p = 0.4177; interaction F(4, 16) = 0.7118, p = 0.5958. Prism applies the Greenhouse-Geisser correction to the fiber-diameter factor only; MyeliMetric also reports a corrected p for the interaction, and its uncorrected p equals Prism's. Prism's mixed-effects fit also tolerates empty animal-by-bin cells, whereas the split-plot ANOVA needs every animal to have fibers in every bin (use fewer bins, or the caliber mixed model, if a cell is empty).

With 3 animals per group the exact permutation test cannot give p below 0.1. The report says so whenever this applies.

If the independent-animal box is not ticked, MyeliMetric saves descriptive animal means only and writes `INFERENCE_NOT_RUN.txt`.

## Settings

| Setting | Default | Notes |
|:--|:--|:--|
| Minimum axon diameter | 0.15 µm | Smaller values excluded and listed in the audit |
| Minimum myelin value | 0.03 µm | Smaller values excluded and listed in the audit |
| Number of bins | 6 | Equal-count bins from control fibers |
| Bin fibers by | Fiber diameter | Axon diameter is available; it avoids coupling bins to myelin thickness |
| Bin ranges from | Pooled controls | First control animal reproduces the published V1 ranges |
| Nested ANOVA uses each animal's bin | Mean | Median matches the GraphPad Prism workflow |

Everything outside the statistics is unchanged from V2: the interface, figures, workbooks, bin method (quantiles of the pooled control fibers) and 2-decimal rounding are the same, and on the V2 example files every Control, Experimental and Summary workbook is identical to V2's output. Experimental fibers outside the control range are not placed in a bin and are listed in the exclusion audit.

## Build the Windows application

On a Windows PC with 64-bit Python 3.11 or 3.12 installed, double-click `BUILD_WINDOWS_EXE.bat`. It creates a build environment, installs `requirements.txt`, runs the test suite and builds `dist\MyeliMetric-2.1.exe`. To check a finished build: `MyeliMetric-2.1.exe --selftest C:\some\empty\folder` writes `SELFTEST_RESULT.txt`.

## Tests

```
python -m unittest discover -s tests -v
```

The 28 tests include reproduction of the GraphPad Prism mixed-effects result, a full run with the median option, exact reproduction of the V2 example output (bin ranges, bin sizes, per-bin statistics, grand means 0.6978 and 0.7889), reproduction of the published V1 bin ranges, agreement of the split-plot ANOVA with an independent implementation (pingouin), agreement of the animal-level test with SciPy, a check that duplicating fibers does not change p-values, and full runs of the 3-animals-per-group example files both with slide IDs (nested model) and with animal IDs only.

## Citation

Ahmad I, Chowdhury FS, Boullerne AI, Gow A, Feinstein DL. MyeliMetric: A Python-Based Toolbox for Standardized G-Ratio Analysis of Axon-Myelin Integrity. ASN Neuro. 2025;18(1):2603411. doi:10.1080/17590914.2025.2603411
