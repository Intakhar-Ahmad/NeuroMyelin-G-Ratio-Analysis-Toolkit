# Changelog

## MyeliMetric-2.1 (2.1.0)

Statistics
- Added animal-level inference: one mean per animal, Student and Welch t tests, exact permutation test, mean difference with 95% CI and Hedges' g.
- Added Group x Subset split-plot ANOVA on animal-by-bin means with Greenhouse-Geisser and Huynh-Feldt corrections and effect sizes. Replaces the fiber-pooled two-way ANOVA, which treated fibers as independent replicates.
- Added a caliber mixed model (g-ratio ~ Group x axon diameter, animal random intercept and slope) that needs no bins.
- Added an animal mixed-effects model (random intercept per animal) that accounts for correlation among fibers from the same animal. It runs with animal IDs alone; when section IDs are provided, sections are modelled as nested within animals.
- Mixed-model tests use N animals - 2 degrees of freedom instead of large-sample z tests.
- Added an independent-animal confirmation; p-values are only computed after it is given.
- Added `Results_Summary.txt` with draft methods and results text.
- Added `Summary/Statistics/Nested_ANOVA_Results.xlsx`: nested ANOVA (Group, Bin, Group x Bin) and animal mixed-model results, with the animal-by-bin means they are based on.
- Added `Summary/Final_Result.png`, the main result figure: every animal in every bin, plotted at the bin's upper edge (µm), with labelled grand means.
- Added `Summary/Statistics/Grand_Mean_GRatio.png`: grand mean g-ratio per group with each animal shown.
- Added the option to run the nested ANOVA on each animal's bin medians instead of means, as in the GraphPad Prism workflow. On the same data the result equals Prism 10.4's mixed-effects analysis.
- If the independent-animal box is not ticked, Analyze now asks directly whether each sample ID is a different animal, instead of silently skipping the statistics.

Unchanged from V2
- Interface layout and colours, all descriptive figures and workbooks, pooled-control bin method and 2-decimal rounding. On the V2 example files all Control, Experimental and Summary workbooks are identical to V2.

Input and processing
- Added optional Slide-ID / Section columns in the wide layout, one after each animal's Ax/My pair, with example files for 3 animals per group.
- Added the long input layout (Group, Animal, Ax, My, optional Section) with a template.
- Added the option to bin by axon diameter.
- Added the option to take bin ranges from the first control animal, which reproduces the published V1 ranges.
- Experimental fibers outside the control range are now reported in the exclusion audit instead of being silently left out.
- The CTL vs EXP summary figure now includes every animal (the original plotting script used animals 1 to 4 only).
- Incomplete Ax/My pairs are excluded and audited.

Application
- Previous results in the same save location are replaced, never mixed with new ones.
- Analysis runs in the background, so the window stays responsive.
- Advanced panel: binning and mean/median options, clean only, bin ranges only, long-format template, example data.
- `--selftest` option for checking a finished build.
- Working PyInstaller specification and build script that runs the test suite first.

## MyeliMetric-V2

- Three-step workflow, one save location with Control, Experimental and Summary folders, save-location safeguard.
- User-adjustable bins (default 6) and exclusion thresholds (defaults 0.15 and 0.03 µm).
- CSV input, activity log, run logs, exclusion audit, advanced stage-by-stage panel.
- Pooled control animals define the bin ranges (published version used the first control animal).
- Standalone Windows distribution.
