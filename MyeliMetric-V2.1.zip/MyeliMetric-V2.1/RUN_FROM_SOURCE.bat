@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Install 64-bit Python 3.11 or 3.12 from python.org first.
  pause
  exit /b 1
)
if not exist ".run_venv\Scripts\python.exe" (
  py -3 -m venv .run_venv
  ".run_venv\Scripts\python.exe" -m pip install -r requirements.txt
)
start "" ".run_venv\Scripts\pythonw.exe" MyeliMetric2.1.py
