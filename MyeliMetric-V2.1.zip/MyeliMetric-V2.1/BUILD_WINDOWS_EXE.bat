@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo =============================================
echo  MyeliMetric-2.1  -  Windows EXE builder
echo =============================================

where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python Launcher py.exe not found. Install 64-bit Python 3.11 or 3.12 from python.org.
  goto :FAILED
)
set "PY_CMD="
py -3.12 -V >nul 2>nul
if not errorlevel 1 set "PY_CMD=py -3.12"
if not defined PY_CMD (
  py -3.11 -V >nul 2>nul
  if not errorlevel 1 set "PY_CMD=py -3.11"
)
if not defined PY_CMD (
  echo ERROR: Install 64-bit Python 3.11 or 3.12 first.
  goto :FAILED
)

if not exist ".build_venv\Scripts\python.exe" (
  echo [1/4] Creating build environment...
  %PY_CMD% -m venv .build_venv
  if errorlevel 1 goto :FAILED
) else (
  echo [1/4] Reusing .build_venv
)
set "PYTHON=.build_venv\Scripts\python.exe"

echo [2/4] Installing packages (internet needed the first time)...
"%PYTHON%" -m pip install --upgrade pip
"%PYTHON%" -m pip install -r requirements.txt
if errorlevel 1 goto :FAILED

echo [3/4] Running the scientific test suite...
"%PYTHON%" -m unittest discover -s tests -v
if errorlevel 1 goto :FAILED

echo [4/4] Building dist\MyeliMetric-2.1.exe ...
"%PYTHON%" -m PyInstaller --clean --noconfirm MyeliMetric.spec
if errorlevel 1 goto :FAILED
if not exist "dist\MyeliMetric-2.1.exe" goto :FAILED

echo.
echo SUCCESS: %CD%\dist\MyeliMetric-2.1.exe
pause
exit /b 0

:FAILED
echo.
echo Build did not complete. Read the first error message above.
pause
exit /b 1
