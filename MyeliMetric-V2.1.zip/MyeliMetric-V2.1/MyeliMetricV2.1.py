"""MyeliMetric-2.1 graphical interface.

Standard workflow (as in V2): choose save location, Step 1 load control data,
Step 2 load experimental data, Step 3 Analyze. Scientific packages are imported
only when needed, so the window opens even if a package is missing.
"""
from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
import traceback
import webbrowser
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

sys.path.insert(0, str(Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))))
from myelimetric import __version__, APP_NAME, CITATION  # noqa: E402  (no heavy imports)

WEBSITE = "https://intakhar-ahmad.github.io/MyeliMetric-Website/"
DEFAULTS = dict(min_axon="0.15", min_myelin="0.03", n_bins=6, bin_variable="Fiber diameter (published)",
                reference="Pooled controls (V2 default)", cell_statistic="Mean (default)", histograms=True)
STAT_CHOICES = {"Mean (default)": "mean", "Median (as in Prism)": "median"}
BIN_CHOICES = {"Fiber diameter (published)": "fiber", "Axon diameter": "axon"}
REF_CHOICES = {"Pooled controls (V2 default)": "pooled", "First control animal (published V1)": "first"}
FILETYPES = [("Excel or CSV", "*.xlsx *.xls *.csv"), ("All files", "*.*")]


def open_folder(path):
    if sys.platform.startswith("win"):
        os.startfile(path)  # noqa: S606
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


# V2 palette
NAVY, PAGE, CARD, MUTED = "#1F2D3D", "#EEF2F6", "#FFFFFF", "#5B6B7B"
BLUE, ORANGE, GREEN, LOGBG = "#2E73B8", "#C0552B", "#1B8A6B", "#0F1720"
FONT = "Segoe UI" if sys.platform.startswith("win") else "DejaVu Sans"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME}  -  Standardized G-Ratio Analysis")
        self.geometry("1180x1000")
        self.minsize(960, 720)
        self.configure(bg=PAGE)
        self.q: queue.Queue = queue.Queue()
        self.busy = False
        self.ctl_path = tk.StringVar(value="")
        self.exp_path = tk.StringVar(value="")
        self.save_dir = tk.StringVar(value="")
        self.confirm = tk.BooleanVar(value=False)
        self.v = {k: (tk.BooleanVar(value=v) if isinstance(v, bool) else
                      tk.IntVar(value=v) if isinstance(v, int) else tk.StringVar(value=v))
                  for k, v in DEFAULTS.items()}
        self._build()
        self.after(100, self._drain)
        self.log("MyeliMetric ready. Choose a save location, load CTL (Step 1) and EXP (Step 2), then Step 3: Analyze.")

    # ------------------------------------------------------------------ layout (V2 look)
    def _card(self, parent, bar_color, title, text):
        card = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground="#D9DFE6")
        card.pack(fill="x", pady=(0, 12))
        tk.Frame(card, bg=bar_color, height=7).pack(fill="x")
        body = tk.Frame(card, bg=CARD, padx=24, pady=10)
        body.pack(fill="x")
        tk.Label(body, text=title, bg=CARD, fg="#1B2733", font=(FONT, 15, "bold")).pack(anchor="w")
        tk.Label(body, text=text, bg=CARD, fg=MUTED, font=(FONT, 10), justify="left",
                 wraplength=1080).pack(anchor="w", pady=(2, 8))
        return body

    def _build(self):
        head = tk.Frame(self, bg=NAVY, padx=28, pady=16)
        head.pack(fill="x")
        left = tk.Frame(head, bg=NAVY)
        left.pack(side="left")
        tk.Label(left, text=APP_NAME, bg=NAVY, fg="white", font=(FONT, 22, "bold")).pack(anchor="w")
        tk.Label(left, text="A Python toolbox for standardized g-ratio analysis of axon\u2013myelin integrity",
                 bg=NAVY, fg="#AFC2D6", font=(FONT, 11)).pack(anchor="w")
        tk.Button(head, text="About / Help", command=self.about, bg=NAVY, fg="white", relief="solid", bd=1,
                  activebackground="#2C3E50", activeforeground="white", font=(FONT, 11), padx=16, pady=6
                  ).pack(side="right")

        status = tk.Label(self, text="Ready.  Start by uploading your control (CTL) data.", bg=NAVY, fg="white",
                          anchor="w", padx=24, pady=8, font=(FONT, 10))
        status.pack(side="bottom", fill="x")
        self.status = status
        foot = tk.Frame(self, bg=PAGE, padx=24, pady=6)
        foot.pack(side="bottom", fill="x")
        tk.Label(foot, text=f"{APP_NAME}  \u00b7  version {__version__}", bg=PAGE, fg="#1B2733",
                 font=(FONT, 10, "bold")).pack(anchor="w")
        tk.Label(foot, text="Please cite:  " + CITATION, bg=PAGE, fg=MUTED, font=(FONT, 9), wraplength=1120,
                 justify="left").pack(anchor="w")

        page = tk.Frame(self, bg=PAGE, padx=28, pady=14)
        page.pack(fill="both", expand=True)

        st = self._card(page, MUTED, "Analysis settings",
                        "Measurements below the thresholds are removed as biologically implausible. The number of "
                        "bins sets how many fiber-diameter groups the fibers are split into. Defaults follow the "
                        "published tool; edit them if needed.")
        row = tk.Frame(st, bg=CARD)
        row.pack(anchor="w")
        def entry(var, w=8):
            return tk.Entry(row, textvariable=var, width=w, justify="center", relief="solid", bd=1, font=(FONT, 11))
        for txt, widget, unit in [("Min axon diameter:", entry(self.v["min_axon"]), "um"),
                                  ("Min myelin thickness:", entry(self.v["min_myelin"]), "um"),
                                  ("Number of bins:", entry(self.v["n_bins"], 4), "(default 6)")]:
            tk.Label(row, text=txt, bg=CARD, font=(FONT, 11)).pack(side="left", padx=(0, 8))
            widget.pack(side="left", ipady=3)
            tk.Label(row, text=unit, bg=CARD, fg=MUTED, font=(FONT, 11)).pack(side="left", padx=(8, 34))
        tk.Button(row, text="Reset to defaults", command=self.reset, relief="solid", bd=1, bg=CARD,
                  font=(FONT, 10), padx=14, pady=3).pack(side="left")

        run = self._card(page, GREEN, "Run analysis",
                         "Load the control data (Step 1) and the experimental data (Step 2), choose one save "
                         "location, then click Step 3 to analyze. The app creates separate Control and Experimental "
                         "folders inside your chosen folder.")
        r1 = tk.Frame(run, bg=CARD)
        r1.pack(fill="x")
        tk.Button(r1, text="Choose save location", command=self.choose_save, relief="solid", bd=1, bg=CARD,
                  font=(FONT, 11), padx=18, pady=7).pack(side="left")
        self.save_lab = tk.Label(r1, text="Save location:  (none chosen yet)", bg=CARD, fg=MUTED, font=(FONT, 10))
        self.save_lab.pack(side="left", padx=20)
        self.save_dir.trace_add("write", lambda *_: self.save_lab.configure(
            text="Save location:  " + (self.save_dir.get() or "(none chosen yet)")))
        r2 = tk.Frame(run, bg=CARD)
        r2.pack(fill="x", pady=(14, 4))
        for i in range(3):
            r2.columnconfigure(i, weight=1, uniform="b")
        big = dict(fg="white", relief="flat", bd=0, font=(FONT, 12), pady=14, activeforeground="white")
        tk.Button(r2, text="Step 1: Load control data", command=self.load_ctl, bg=BLUE,
                  activebackground="#25609A", **big).grid(row=0, column=0, sticky="ew", padx=(0, 9))
        tk.Button(r2, text="Step 2: Load experimental data", command=self.load_exp, bg=ORANGE,
                  activebackground="#A24623", **big).grid(row=0, column=1, sticky="ew", padx=9)
        self.go = tk.Button(r2, text="Step 3: Analyze", command=self.analyze, bg=GREEN,
                            activebackground="#16725A", **big)
        self.go.grid(row=0, column=2, sticky="ew", padx=(9, 0))
        self.files_lab = tk.Label(run, text="", bg=CARD, fg=MUTED, font=(FONT, 9), justify="left", anchor="w")
        self.files_lab.pack(fill="x", pady=(4, 0))
        for var in (self.ctl_path, self.exp_path):
            var.trace_add("write", lambda *_: self.files_lab.configure(text=(
                (f"CTL: {self.ctl_path.get()}" if self.ctl_path.get() else "")
                + (f"\nEXP: {self.exp_path.get()}" if self.exp_path.get() else ""))))
        tk.Checkbutton(run, variable=self.confirm, bg=CARD, activebackground=CARD, font=(FONT, 10),
                       anchor="w", justify="left", wraplength=1060, text=(
            "Each sample ID (CTL1, CTL2, EXP1 ...) is a different animal (needed for the animal-level nested "
            "statistics). Slides or sections go in an optional Slide-ID column.")).pack(fill="x", pady=(8, 0))

        adv_card = tk.Frame(page, bg=CARD, highlightthickness=1, highlightbackground="#D9DFE6")
        adv_card.pack(fill="x", pady=(0, 12))
        hdr = tk.Frame(adv_card, bg=CARD, padx=24, pady=10)
        hdr.pack(fill="x")
        self.adv_open = tk.BooleanVar(value=False)
        self.adv_arrow = tk.Label(hdr, text="\u25b8", bg=CARD, font=(FONT, 11))
        self.adv_arrow.pack(side="left", padx=(0, 10))
        t = tk.Frame(hdr, bg=CARD)
        t.pack(side="left", fill="x")
        tk.Label(t, text="For advanced users: run stages individually", bg=CARD, fg="#1B2733",
                 font=(FONT, 14, "bold"), cursor="hand2").pack(anchor="w")
        tk.Label(t, text="Optional. Most users only need the three buttons above. Use this to change the binning "
                         "options, re-run a single stage, or get templates and example data.",
                 bg=CARD, fg=MUTED, font=(FONT, 10), wraplength=1000, justify="left").pack(anchor="w")
        for w in (hdr, self.adv_arrow, *t.winfo_children()):
            w.bind("<Button-1>", lambda e: self.toggle_adv())
        self.adv = tk.Frame(adv_card, bg=CARD, padx=46, pady=8)
        o = tk.Frame(self.adv, bg=CARD)
        o.pack(fill="x", pady=(0, 8))
        tk.Label(o, text="Bin fibers by:", bg=CARD, font=(FONT, 10)).pack(side="left")
        ttk.Combobox(o, textvariable=self.v["bin_variable"], values=list(BIN_CHOICES), state="readonly",
                     width=28).pack(side="left", padx=(6, 24))
        tk.Label(o, text="Bin ranges from:", bg=CARD, font=(FONT, 10)).pack(side="left")
        ttk.Combobox(o, textvariable=self.v["reference"], values=list(REF_CHOICES), state="readonly",
                     width=34).pack(side="left", padx=6)
        o2 = tk.Frame(self.adv, bg=CARD)
        o2.pack(fill="x", pady=(0, 8))
        tk.Label(o2, text="Nested ANOVA uses each animal's bin:", bg=CARD, font=(FONT, 10)).pack(side="left")
        ttk.Combobox(o2, textvariable=self.v["cell_statistic"], values=list(STAT_CHOICES), state="readonly",
                     width=22).pack(side="left", padx=6)
        tk.Checkbutton(o2, text="Save histograms", variable=self.v["histograms"], bg=CARD,
                       activebackground=CARD, font=(FONT, 10)).pack(side="left", padx=24)
        b = tk.Frame(self.adv, bg=CARD)
        b.pack(fill="x")
        for i, (txt, cmd) in enumerate([("Clean data only (+ exclusion audit)", self.adv_clean),
                                         ("Control bin ranges only", self.adv_ranges),
                                         ("Save long-format template", self.adv_template),
                                         ("Copy example data", self.adv_examples),
                                         ("Open output folder", self.open_out)]):
            tk.Button(b, text=txt, command=cmd, relief="solid", bd=1, bg=CARD, font=(FONT, 10), padx=10,
                      pady=4).pack(side="left", padx=(0, 8))

        logc = self._card(page, MUTED, "Activity log",
                          "Progress, saved file locations, and the exclusion audit trail appear here.")
        logc.master.pack_configure(fill="both", expand=True)
        logc.pack_configure(fill="both", expand=True)
        self.text = ScrolledText(logc, height=8, font=("Consolas", 10), wrap="word", state="disabled",
                                 bg=LOGBG, fg="#E6EDF3", insertbackground="white", relief="flat", padx=10, pady=8)
        self.text.pack(fill="both", expand=True)

    # ----------------------------------------------------------------- helpers
    def log(self, msg):
        self.text.configure(state="normal")
        self.text.insert("end", msg.rstrip() + "\n")
        self.text.see("end")
        self.text.configure(state="disabled")
        if hasattr(self, "status"):
            self.status.configure(text=msg.split("] ", 1)[-1][:150])

    def _drain(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "log":
                    self.log(payload)
                elif kind == "done":
                    self._finish(*payload)
        except queue.Empty:
            pass
        self.after(100, self._drain)

    def reset(self):
        for k, val in DEFAULTS.items():
            self.v[k].set(val)
        self.log("Settings reset to defaults (0.15 um axon, 0.03 um myelin, 6 bins, fiber-diameter bins, pooled controls).")

    def toggle_adv(self):
        if self.adv_open.get():
            self.adv.pack_forget()
            self.adv_arrow.configure(text="\u25b8")
        else:
            self.adv.pack(fill="x")
            self.adv_arrow.configure(text="\u25be")
            # Grow the window so the activity log keeps its space while the panel is open.
            self.update_idletasks()
            need = self.winfo_reqheight()
            if self.winfo_height() < need:
                self.geometry(f"{self.winfo_width()}x{min(need, self.winfo_screenheight() - 60)}")
        self.adv_open.set(not self.adv_open.get())

    def settings(self):
        from myelimetric.processing import Settings
        try:
            s = Settings(min_axon=float(self.v["min_axon"].get()), min_myelin=float(self.v["min_myelin"].get()),
                         n_bins=int(self.v["n_bins"].get()), bin_variable=BIN_CHOICES[self.v["bin_variable"].get()],
                         reference=REF_CHOICES[self.v["reference"].get()],
                         cell_statistic=STAT_CHOICES[self.v["cell_statistic"].get()], make_histograms=self.v["histograms"].get(),
                         animals_confirmed=self.confirm.get())
            return s.validate()
        except (ValueError, tk.TclError) as e:
            messagebox.showerror("Settings", f"Please check the analysis settings.\n\n{e}")
            return None

    def choose_save(self):
        p = filedialog.askdirectory(title="Choose one folder for all results")
        if p:
            self.save_dir.set(p)
            self.log(f"Save location: {p}")

    def _pick(self, var, title):
        p = filedialog.askopenfilename(title=title, filetypes=FILETYPES)
        if p:
            var.set(p)
            self.log(f"Loaded (will be processed at Step 3): {p}")

    def load_ctl(self):
        self._pick(self.ctl_path, "Select the control (CTL) file")

    def load_exp(self):
        self._pick(self.exp_path, "Select the experimental (EXP) file")

    def open_out(self):
        if self.save_dir.get() and Path(self.save_dir.get()).exists():
            open_folder(self.save_dir.get())
        else:
            messagebox.showinfo("Output folder", "Choose a save location first.")

    def _ready(self, need_save=True):
        if self.busy:
            messagebox.showinfo(APP_NAME, "An analysis is already running.")
            return False
        if need_save and not self.save_dir.get():
            messagebox.showwarning("Save location", "Please click 'Choose save location' and select a folder first.")
            return False
        if not self.ctl_path.get():
            messagebox.showwarning("Control data", "Please load control data with Step 1. CTL data define the "
                                                   "fiber-diameter bin ranges.")
            return False
        return True

    def _run(self, label, fn, *args):
        self.busy = True
        self.go.configure(state="disabled", text="Analyzing...")
        self.log(f"--- {label} ---")

        def work():
            try:
                res = fn(*args, callback=lambda m: self.q.put(("log", m)))
                self.q.put(("done", (label, res, None)))
            except Exception as exc:  # report every failure to the user, never crash the window
                self.q.put(("log", traceback.format_exc()))
                self.q.put(("done", (label, None, exc)))

        threading.Thread(target=work, daemon=True).start()

    def _finish(self, label, res, exc):
        self.busy = False
        self.go.configure(state="normal", text="Step 3: Analyze")
        if exc is not None:
            messagebox.showerror(label, f"{label} stopped:\n\n{exc}")
            return
        if label == "Analysis":
            stats = (res or {}).get("statistics", {})
            msg = f"Analysis complete.\n\nResults are in:\n{res['save_dir']}"
            if stats and not stats.get("inference"):
                msg += ("\n\nP-values were not calculated because the independent-animal box was not ticked. "
                        "See Summary/Statistics/INFERENCE_NOT_RUN.txt.")
            elif stats:
                msg += "\n\nAnimal-level statistics: Summary/Statistics/Results_Summary.txt"
            if messagebox.askyesno("Done", msg + "\n\nOpen the output folder now?"):
                open_folder(res["save_dir"])
        else:
            messagebox.showinfo(label, f"{label} finished.\n\n{res}")

    # ----------------------------------------------------------------- actions
    def analyze(self):
        if not self._ready():
            return
        s = self.settings()
        if s is None:
            return
        if self.exp_path.get() and not s.animals_confirmed:
            ans = messagebox.askyesnocancel(
                "Confirm independent animals",
                "Is each sample ID (CTL1, CTL2, EXP1 ...) a different animal?\n\n"
                "YES: run the full statistics (split-plot ANOVA, animal mixed model with nested sections, "
                "animal-level tests).\n"
                "NO: save descriptive results only, without p-values.\n"
                "CANCEL: go back.")
            if ans is None:
                return
            if ans:
                self.confirm.set(True)
                s.animals_confirmed = True
        try:
            from myelimetric import pipeline
        except ImportError as e:
            messagebox.showerror("Missing package", f"A required package could not be loaded:\n{e}\n\n"
                                                    "Install the packages in requirements.txt.")
            return
        self._run("Analysis", pipeline.analyze, self.ctl_path.get(), self.exp_path.get() or None,
                  self.save_dir.get(), s)

    def adv_clean(self):
        if self._ready() and (s := self.settings()):
            from myelimetric import pipeline
            self._run("Clean data only", pipeline.clean_only, self.ctl_path.get(), self.exp_path.get() or None,
                      self.save_dir.get(), s)

    def adv_ranges(self):
        if self._ready() and (s := self.settings()):
            from myelimetric import pipeline
            self._run("Control bin ranges", pipeline.ranges_only, self.ctl_path.get(), self.save_dir.get(), s)

    def adv_template(self):
        p = filedialog.asksaveasfilename(title="Save long-format template", defaultextension=".csv",
                                         initialfile="MyeliMetric_long_format_template.csv",
                                         filetypes=[("CSV", "*.csv")])
        if p:
            from myelimetric import pipeline
            pipeline.write_long_template(p)
            self.log(f"Template saved: {p}. One row per fiber; Section is optional.")

    def adv_examples(self):
        import shutil
        src = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) / "example_Dataset"
        dst = filedialog.askdirectory(title="Copy example files to")
        if dst:
            for f in src.glob("*.*"):
                shutil.copy2(f, dst)
            self.log(f"Example files copied to {dst}")

    def about(self):
        win = tk.Toplevel(self)
        win.title("About / Help")
        win.resizable(False, False)
        body = ttk.Frame(win, padding=16)
        body.pack()
        ttk.Label(body, text=f"{APP_NAME}  version {__version__}", style="Title.TLabel").pack(anchor="w")
        txt = ("Input: paired <ID>_Ax and <ID>_My columns in µm, one file per group, each pair optionally "
               "followed by a Slide-ID (or Section) column; or one long table with Group, Animal, Ax, My and "
               "optional Section.\n\nSection/slide IDs are optional. Without them the mixed models use animal "
               "IDs alone; with them, sections are modelled as nested within animals.\n\n"
               "_My must be the full myelin contribution across the fiber (2 x radial thickness), because "
               "fiber diameter = Ax + My and g-ratio = Ax / (Ax + My).\n\n"
               "Statistics use the animal as the experimental unit. Fibers and sections are technical "
               "subsamples and are never counted as n.\n\nPlease cite:\n" + CITATION)
        ttk.Label(body, text=txt, wraplength=520, justify="left").pack(anchor="w", pady=8)
        ttk.Button(body, text="Open website and manual", command=lambda: webbrowser.open(WEBSITE)).pack(side="left")
        ttk.Button(body, text="Close", command=win.destroy).pack(side="right")


def selftest(out_dir):
    """Run the bundled example data end to end (MyeliMetric-2.1.exe --selftest <folder>)."""
    from myelimetric import pipeline
    from myelimetric.processing import Settings
    ex = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) / "example_Dataset"
    res = pipeline.analyze(ex / "Example_CTL.xlsx", ex / "Example_EXP.xlsx", out_dir,
                           Settings(animals_confirmed=True, make_histograms=False), callback=lambda m: None)
    ok = res["statistics"]["inference"]
    Path(out_dir, "SELFTEST_RESULT.txt").write_text("PASS\n" if ok else "FAIL\n")
    return 0 if ok else 1


def main():
    if len(sys.argv) >= 3 and sys.argv[1] == "--selftest":
        sys.exit(selftest(sys.argv[2]))
    App().mainloop()


if __name__ == "__main__":
    main()
