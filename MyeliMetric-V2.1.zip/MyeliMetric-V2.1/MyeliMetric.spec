# PyInstaller specification for the MyeliMetric-2.1 single-file Windows application.
# Build with:  python -m PyInstaller --clean --noconfirm MyeliMetric.spec
from PyInstaller.utils.hooks import collect_submodules

hidden = (collect_submodules("myelimetric")
          + collect_submodules("statsmodels.regression")
          + collect_submodules("statsmodels.formula")
          + ["patsy", "openpyxl", "scipy.stats", "scipy.special", "matplotlib.backends.backend_agg"])

a = Analysis(
    ["MyeliMetric2.1.py"],
    pathex=["."],
    datas=[("example_Dataset", "example_Dataset")],
    hiddenimports=hidden,
    excludes=["pytest", "IPython", "notebook", "PyQt5", "PySide6", "seaborn", "pingouin"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="MyeliMetric-2.1",
    console=False,
    upx=False,
    runtime_tmpdir=None,
)
